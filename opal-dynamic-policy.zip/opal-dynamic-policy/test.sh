#!/bin/bash
# test.sh – Integration tests for the opal-dynamic-policy stack.
#
# Usage:
#   ./test.sh [pep-proxy-url] [bundle-server-url]
#
# The script manages kubectl port-forward automatically.
# Set AUTO_PORT_FORWARD=false to use pre-existing port-forwards.
#
# Environment variables:
#   TENANT_ID               – tenant used in tests        (default: tenant-test-001)
#   JWT_SECRET              – HS256 secret matching deploy (default: jwt-secret)
#   NAMESPACE               – K8s namespace               (default: opal-dynamic-policy)
#   AUTO_PORT_FORWARD       – start port-forward auto     (default: true)
#   OIDC_BASE_URL           – set to test Keycloak iss extraction
#                             (default: "" → uses tenant_id claim fallback)
#   TEST_GATEWAY            – run Section 10 gateway end-to-end tests
#                             (default: false)
#   AGENTGATEWAY_NAMESPACE  – namespace of the agentgateway proxy
#                             (default: agentgateway-system-opa)
#   GATEWAY_URL             – agentgateway base URL (default: http://localhost:8080)

NAMESPACE=${NAMESPACE:-"opal-dynamic-policy"}
PEP_URL=${1:-"http://localhost:8000"}
BUNDLE_URL=${2:-"http://localhost:8001"}
TENANT_ID=${TENANT_ID:-"tenant-test-001"}
JWT_SECRET=${JWT_SECRET:-"jwt-secret"}
AUTO_PORT_FORWARD=${AUTO_PORT_FORWARD:-true}
TEST_GATEWAY=${TEST_GATEWAY:-false}
AGENTGATEWAY_NAMESPACE=${AGENTGATEWAY_NAMESPACE:-"agentgateway-system-opa"}
GATEWAY_URL=${GATEWAY_URL:-"http://localhost:8080"}
# Fake OIDC base for iss claim in test tokens (Keycloak format)
# auth.py HS256 fallback will extract tenant from: {FAKE_OIDC}/realms/{tenant}
FAKE_OIDC="http://keycloak.test"

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

pass()    { echo -e "${GREEN}  ✓ $1${NC}"; }
fail()    { echo -e "${RED}  ✗ $1${NC}"; EXIT_CODE=1; }
section() { echo -e "\n${YELLOW}=== $1 ===${NC}"; }
info()    { echo -e "${CYAN}  i $1${NC}"; }

EXIT_CODE=0
PF_PIDS=()

# ---------------------------------------------------------------------------
# Port-forward management
# ---------------------------------------------------------------------------
_wait_for_port() {
    local port=$1 retries=15
    while [ $retries -gt 0 ]; do
        if curl -s -o /dev/null --connect-timeout 1 "http://localhost:$port" 2>/dev/null; then
            return 0
        fi
        sleep 1
        retries=$((retries - 1))
    done
    return 1
}

_wait_for_tcp() {
    # Check raw TCP (for gRPC port which speaks HTTP/2, not HTTP/1)
    local port=$1 retries=15
    while [ $retries -gt 0 ]; do
        if timeout 1 bash -c "echo >/dev/tcp/localhost/$port" 2>/dev/null; then
            return 0
        fi
        sleep 1
        retries=$((retries - 1))
    done
    return 1
}

start_port_forward() {
    info "Starting kubectl port-forward (namespace: $NAMESPACE)..."

    # Kill any stale forwarding on the target ports
    local ports="8000 8001 9000"
    [ "$TEST_GATEWAY" = "true" ] && ports="$ports 8080"
    for port in $ports; do
        lsof -ti "tcp:$port" 2>/dev/null | xargs kill -9 2>/dev/null || true
    done
    sleep 1

    kubectl port-forward svc/pep-proxy     8000:8000 -n "$NAMESPACE" \
        >/tmp/pf-pep.log 2>&1 &
    PF_PIDS+=($!)

    kubectl port-forward svc/bundle-server 8001:8001 -n "$NAMESPACE" \
        >/tmp/pf-bundle.log 2>&1 &
    PF_PIDS+=($!)

    # gRPC ext-authz port
    kubectl port-forward svc/pep-proxy 9000:9000 -n "$NAMESPACE" \
        >/tmp/pf-grpc.log 2>&1 &
    PF_PIDS+=($!)

    # agentgateway management port (only when TEST_GATEWAY=true)
    if [ "$TEST_GATEWAY" = "true" ]; then
        kubectl port-forward svc/agent-gateway 8080:8080 -n "$AGENTGATEWAY_NAMESPACE" \
            >/tmp/pf-gw.log 2>&1 &
        PF_PIDS+=($!)
    fi

    info "Waiting for HTTP port-forwards to be ready..."
    if ! _wait_for_port 8000; then
        echo -e "${RED}  ✗ pep-proxy port-forward failed:${NC}"
        cat /tmp/pf-pep.log
        exit 1
    fi
    if ! _wait_for_port 8001; then
        echo -e "${RED}  ✗ bundle-server port-forward failed:${NC}"
        cat /tmp/pf-bundle.log
        exit 1
    fi
    if [ "$TEST_GATEWAY" = "true" ]; then
        if ! _wait_for_port 8080; then
            echo -e "${RED}  ✗ agentgateway port-forward failed:${NC}"
            cat /tmp/pf-gw.log
            exit 1
        fi
        info "Port-forwards established: pep-proxy:8000, bundle-server:8001, gRPC:9000, gateway:8080"
    else
        info "Port-forwards established: pep-proxy:8000, bundle-server:8001, gRPC:9000"
    fi
}

cleanup() {
    if [ ${#PF_PIDS[@]} -gt 0 ]; then
        info "Stopping port-forwards (PIDs: ${PF_PIDS[*]})..."
        kill "${PF_PIDS[@]}" 2>/dev/null || true
        wait "${PF_PIDS[@]}" 2>/dev/null || true
    fi
    rm -f /tmp/pf-pep.log /tmp/pf-bundle.log /tmp/pf-grpc.log /tmp/pf-gw.log /tmp/http_body
}
trap cleanup EXIT

# ---------------------------------------------------------------------------
# Preflight connectivity check (manual mode)
# ---------------------------------------------------------------------------
preflight_check() {
    local url=$1 label=$2
    local code
    code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 \
        "$url" 2>/dev/null || true)
    if [ "${code:-000}" = "000" ]; then
        echo -e "${RED}  ✗ Cannot reach $label at $url${NC}"
        exit 1
    fi
}

if [ "$AUTO_PORT_FORWARD" = "true" ]; then
    start_port_forward
else
    info "AUTO_PORT_FORWARD=false – expecting pre-existing port-forwards"
    preflight_check "$PEP_URL/health"    "pep-proxy"
    preflight_check "$BUNDLE_URL/health" "bundle-server"
fi
info "Connectivity OK – starting tests"
echo ""

# ---------------------------------------------------------------------------
# JWT generation (HS256 via OpenSSL – no external dependencies)
#
# Includes an iss claim in Keycloak format so auth.py exercises the
# issuer-based tenant extraction path (_extract_tenant_from_issuer).
# ---------------------------------------------------------------------------
make_jwt() {
    local sub=$1 tenant=$2 roles_json=$3
    local header payload sig
    # iss = {FAKE_OIDC}/realms/{tenant}  → auth.py extracts tenant from /realms/
    header=$(printf '{"alg":"HS256","typ":"JWT"}' \
        | base64 | tr -d '=' | tr '+/' '-_' | tr -d '\n')
    payload=$(printf \
        '{"sub":"%s","tenant_id":"%s","roles":%s,"email":"%s@example.com","iss":"%s/realms/%s"}' \
        "$sub" "$tenant" "$roles_json" "$sub" "$FAKE_OIDC" "$tenant" \
        | base64 | tr -d '=' | tr '+/' '-_' | tr -d '\n')
    sig=$(printf '%s.%s' "$header" "$payload" \
        | openssl dgst -sha256 -hmac "$JWT_SECRET" -binary \
        | base64 | tr -d '=' | tr '+/' '-_' | tr -d '\n')
    printf '%s.%s.%s' "$header" "$payload" "$sig"
}

SUPER_JWT=$(make_jwt "super-admin-001"  "$TENANT_ID" '["super_admin"]')
ADMIN_JWT=$(make_jwt "tenant-admin-001" "$TENANT_ID" '["tenant_admin"]')
USER_JWT=$(make_jwt  "normal-user-001"  "$TENANT_ID" '["viewer"]')

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
http() {
    local method=$1; shift
    local url=$1;    shift
    > /tmp/http_body
    curl -s -o /tmp/http_body -w "%{http_code}" --connect-timeout 5 \
        -X "$method" "$url" "$@" 2>/dev/null || true
}

check_status() {
    local label=$1 expected=$2 actual=$3
    if [ "$actual" = "$expected" ]; then
        pass "$label (HTTP $actual)"
    else
        fail "$label (expected HTTP $expected, got HTTP $actual)"
        python3 -m json.tool /tmp/http_body 2>/dev/null || cat /tmp/http_body
        echo
    fi
}

json_field() {
    python3 -c "import sys,json; d=json.load(open('/tmp/http_body')); print($1)" 2>/dev/null || echo "?"
}

# ===========================================================================
# 1. Health checks
# ===========================================================================
section "1. Health Checks"

STATUS=$(http GET "$PEP_URL/health")
check_status "pep-proxy /health" "200" "$STATUS"

STATUS=$(http GET "$BUNDLE_URL/health")
check_status "bundle-server /health" "200" "$STATUS"

# ===========================================================================
# 2. gRPC ext-authz port connectivity
# ===========================================================================
section "2. gRPC Ext-Authz Server (port 9000)"

if _wait_for_tcp 9000; then
    pass "gRPC ext-authz port 9000 is open"
else
    fail "gRPC ext-authz port 9000 is not reachable"
    info "Check pep-proxy logs: kubectl logs -l app=pep-proxy -c opal-proxy -n $NAMESPACE"
fi

# Optional: full gRPC test with grpcurl
if command -v grpcurl &>/dev/null; then
    info "grpcurl found – testing Authorization/Check via reflection (if enabled)..."
    # Note: pep-proxy does not enable gRPC server reflection by default.
    # To use grpcurl with proto file:
    #   grpcurl -plaintext -proto pep-proxy/proto/ext_authz.proto \
    #     -d '{"attributes":{"request":{"http":{"method":"GET","path":"/","headers":{"authorization":"Bearer '$ADMIN_JWT'","x-authz-resource":"documents","x-authz-action":"read"}}}}}' \
    #     localhost:9000 envoy.service.auth.v3.Authorization/Check
    info "Run the grpcurl command above manually with pep-proxy/proto/ext_authz.proto"
else
    info "grpcurl not found – skipping full gRPC protocol test"
    info "Install: https://github.com/fullstorydev/grpcurl"
fi

# ===========================================================================
# 3. Bundle Server – tenant / data / bundle endpoints
# ===========================================================================
section "3. Bundle Server – Tenant / Data APIs"

STATUS=$(http GET "$BUNDLE_URL/api/v1/tenants")
check_status "List tenants" "200" "$STATUS"

STATUS=$(http POST "$BUNDLE_URL/api/v1/policies" \
    -H "Content-Type: application/json" \
    -d "{\"id\":\"\",\"role\":\"viewer\",\"resource\":\"documents\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
check_status "Create policy via bundle-server" "200" "$STATUS"
info "policy_id: $(json_field 'd.get("policy_id","?")')"

STATUS=$(http GET "$BUNDLE_URL/api/v1/tenants/$TENANT_ID/policies")
check_status "Get tenant policies" "200" "$STATUS"

STATUS=$(http GET "$BUNDLE_URL/api/v1/data/$TENANT_ID")
check_status "Get tenant OPA data" "200" "$STATUS"
info "role_mappings: $(json_field 'd.get("tenants",{}).get("'"$TENANT_ID"'",{}).get("role_mappings",{})')"

STATUS=$(http GET "$BUNDLE_URL/api/v1/opa-bundle")
check_status "Download OPA bundle tar.gz" "200" "$STATUS"

info "Waiting 3 s for OPA to receive the policy bundle..."
sleep 3

# ===========================================================================
# 4. PEP Proxy – policy templates
# ===========================================================================
section "4. PEP Proxy – Policy Templates"

STATUS=$(http GET "$PEP_URL/api/v1/policies/templates" \
    -H "Authorization: Bearer $USER_JWT")
check_status "List templates (any valid JWT → 200)" "200" "$STATUS"
info "templates: $(json_field 'd.get("templates",[])')"

# ===========================================================================
# 5. PEP Proxy – policy creation (tenant_admin only)
# ===========================================================================
section "5. PEP Proxy – Policy Creation"

STATUS=$(http POST "$PEP_URL/api/v1/policies/role" \
    -H "Authorization: Bearer $ADMIN_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"role\":\"viewer\",\"resource\":\"reports\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
check_status "Create role policy (tenant_admin → 200)" "200" "$STATUS"
POLICY_ID=$(json_field 'd.get("policy_id","viewer_reports_read")')
info "created policy_id: $POLICY_ID"

STATUS=$(http POST "$PEP_URL/api/v1/policies/role" \
    -H "Authorization: Bearer $USER_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"role\":\"viewer\",\"resource\":\"reports\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
check_status "Create role policy (normal_user → 403)" "403" "$STATUS"

STATUS=$(http POST "$PEP_URL/api/v1/policies/template/role_based" \
    -H "Authorization: Bearer $ADMIN_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"tenant_id\":\"$TENANT_ID\",\"role\":\"viewer\",\"resource\":\"documents\",\"action\":\"read\"}")
check_status "Render role_based template (tenant_admin → 200)" "200" "$STATUS"

info "Waiting 3 s for OPA policy update to propagate..."
sleep 3

# ===========================================================================
# 6. PEP Proxy – Policy CRUD (list / update / delete / cross-tenant isolation)
# ===========================================================================
section "6. PEP Proxy – Policy CRUD + Cross-Tenant Isolation"

STATUS=$(http GET "$PEP_URL/api/v1/policies" \
    -H "Authorization: Bearer $USER_JWT")
check_status "List policies (normal_user → 200)" "200" "$STATUS"
info "policy count: $(json_field 'd.get("count","?")')"

STATUS=$(http PUT "$PEP_URL/api/v1/policies/role/$POLICY_ID" \
    -H "Authorization: Bearer $ADMIN_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"role\":\"viewer\",\"resource\":\"reports\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
check_status "Update policy (tenant_admin → 200)" "200" "$STATUS"

STATUS=$(http PUT "$PEP_URL/api/v1/policies/role/$POLICY_ID" \
    -H "Authorization: Bearer $USER_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"role\":\"viewer\",\"resource\":\"reports\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
check_status "Update policy (normal_user → 403)" "403" "$STATUS"

# Cross-tenant: admin cannot write policy for a different tenant
STATUS=$(http PUT "$PEP_URL/api/v1/policies/role/$POLICY_ID" \
    -H "Authorization: Bearer $ADMIN_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"role\":\"viewer\",\"resource\":\"reports\",\"action\":\"read\",\"tenant_id\":\"other-tenant\"}")
check_status "Cross-tenant update rejected (403)" "403" "$STATUS"

STATUS=$(http DELETE "$PEP_URL/api/v1/policies/role/$POLICY_ID?tenant_id=other-tenant" \
    -H "Authorization: Bearer $ADMIN_JWT")
check_status "Cross-tenant delete rejected (403)" "403" "$STATUS"

STATUS=$(http DELETE "$PEP_URL/api/v1/policies/role/$POLICY_ID?tenant_id=$TENANT_ID" \
    -H "Authorization: Bearer $USER_JWT")
check_status "Delete policy (normal_user → 403)" "403" "$STATUS"

STATUS=$(http DELETE "$PEP_URL/api/v1/policies/role/$POLICY_ID?tenant_id=$TENANT_ID" \
    -H "Authorization: Bearer $ADMIN_JWT")
check_status "Delete policy (tenant_admin → 200)" "200" "$STATUS"

STATUS=$(http GET "$PEP_URL/api/v1/policies" \
    -H "Authorization: Bearer $ADMIN_JWT")
check_status "List policies after delete (→ 200)" "200" "$STATUS"
info "policy count after delete: $(json_field 'd.get("count","?")')"

# ===========================================================================
# 7. PEP Proxy – authorization checks via OPA (/api/v1/auth/check)
# ===========================================================================
section "7. PEP Proxy – Authorization Checks (OPA)"

_auth_check() {
    local label=$1 jwt=$2 resource=$3 action=$4 tenant=$5 want_allow=$6
    STATUS=$(http POST "$PEP_URL/api/v1/auth/check" \
        -H "Authorization: Bearer $jwt" \
        -H "Content-Type: application/json" \
        -d "{\"resource\":\"$resource\",\"action\":\"$action\",\"tenant_id\":\"$tenant\"}")
    check_status "$label (HTTP 200)" "200" "$STATUS"
    local decision
    decision=$(json_field 'd.get("allowed",False)')
    if   [ "$want_allow" = "true"  ] && [ "$decision" = "True"  ]; then
        pass "$label → ALLOW"
    elif [ "$want_allow" = "false" ] && [ "$decision" = "False" ]; then
        pass "$label → DENY"
    else
        fail "$label → expected $([ "$want_allow" = "true" ] && echo ALLOW || echo DENY), got $decision"
    fi
}

# viewer role has documents:read from the bundle-server seed in section 3
_auth_check "viewer reads documents"             "$USER_JWT"  "documents" "read"   "$TENANT_ID"   "true"
_auth_check "viewer deletes documents"           "$USER_JWT"  "documents" "delete" "$TENANT_ID"   "false"
_auth_check "tenant_admin deletes documents"     "$ADMIN_JWT" "documents" "delete" "$TENANT_ID"   "true"
_auth_check "super_admin cross-tenant operation" "$SUPER_JWT" "anything"  "delete" "other-tenant" "true"

# ===========================================================================
# 8. JWT issuer-based tenant extraction
# ===========================================================================
section "8. JWT Issuer-Based Tenant Extraction"

# The JWTs generated by make_jwt include:
#   "iss": "http://keycloak.test/realms/<tenant>"
# In HS256 dev mode auth.py runs: _extract_tenant_from_issuer(iss)
# and should resolve the same tenant_id as the claim.
info "Test JWT iss: ${FAKE_OIDC}/realms/${TENANT_ID}"
info "(HS256 dev mode: auth.py extracts tenant from /realms/ path in iss)"

# If tenant extracted from iss is correct, the following will succeed
STATUS=$(http GET "$PEP_URL/api/v1/policies" \
    -H "Authorization: Bearer $ADMIN_JWT")
check_status "Auth with iss-embedded tenant works (→ 200)" "200" "$STATUS"

# Attempt to forge a token whose iss points to a different tenant but
# whose tenant_id claim matches. auth.py should use the iss-derived tenant.
FORGE_JWT=$(make_jwt "attacker" "other-tenant" '["tenant_admin"]')
STATUS=$(http POST "$PEP_URL/api/v1/policies/role" \
    -H "Authorization: Bearer $FORGE_JWT" \
    -H "Content-Type: application/json" \
    -d "{\"role\":\"viewer\",\"resource\":\"data\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
check_status "Cross-tenant write via forged token rejected (403)" "403" "$STATUS"

# ===========================================================================
# 9. Reject invalid / missing tokens
# ===========================================================================
section "9. Auth Rejection"

STATUS=$(http GET "$PEP_URL/api/v1/policies/templates")
check_status "No token → 403" "403" "$STATUS"

STATUS=$(http GET "$PEP_URL/api/v1/policies/templates" \
    -H "Authorization: Bearer invalidtoken")
check_status "Bad token → 401" "401" "$STATUS"

# ===========================================================================
# 10. Agentgateway end-to-end (TEST_GATEWAY=true)
#
# Exercises the full chain:
#   curl → gateway:8080 → gRPC ext-authz (pep-proxy:9000) → OPA → pep-proxy:8000
#
# Run with: TEST_GATEWAY=true ./test.sh
# ===========================================================================
if [ "$TEST_GATEWAY" = "true" ]; then
    section "10. Agentgateway End-to-End (gateway:8080)"

    # ── 10a: Connectivity ────────────────────────────────────────────────────
    STATUS=$(http GET "$GATEWAY_URL/api/v1/policies/templates")
    check_status "Gateway reachable (no token → 403)" "403" "$STATUS"

    # ── 10b: Auth rejection through gateway ─────────────────────────────────
    # agentgateway maps all ext-authz denials (including 401 Unauthorized) to
    # HTTP 403, so we expect 403 regardless of the underlying denial reason.
    STATUS=$(http GET "$GATEWAY_URL/api/v1/policies/templates" \
        -H "Authorization: Bearer invalidtoken")
    check_status "Bad token via gateway → 403" "403" "$STATUS"

    # ── 10c: Authenticated requests through gateway ──────────────────────────
    # The gateway enforces OPA for ALL requests.  viewer only has documents:read
    # in role_mappings; OPA denies templates:list and policies:list for viewer.
    # Use tenant_admin (unconditionally allowed by OPA within own tenant).
    STATUS=$(http GET "$GATEWAY_URL/api/v1/policies/templates" \
        -H "Authorization: Bearer $ADMIN_JWT")
    check_status "List templates via gateway (tenant_admin → 200)" "200" "$STATUS"

    STATUS=$(http GET "$GATEWAY_URL/api/v1/policies" \
        -H "Authorization: Bearer $ADMIN_JWT")
    check_status "List policies via gateway (tenant_admin → 200)" "200" "$STATUS"

    # ── 10d: Policy write through gateway (tenant_admin only) ────────────────
    STATUS=$(http POST "$GATEWAY_URL/api/v1/policies/role" \
        -H "Authorization: Bearer $ADMIN_JWT" \
        -H "Content-Type: application/json" \
        -d "{\"role\":\"viewer\",\"resource\":\"gw-reports\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
    check_status "Create policy via gateway (tenant_admin → 200)" "200" "$STATUS"
    GW_POLICY_ID=$(json_field 'd.get("policy_id","viewer_gw-reports_read")')
    info "created policy_id: $GW_POLICY_ID"

    STATUS=$(http POST "$GATEWAY_URL/api/v1/policies/role" \
        -H "Authorization: Bearer $USER_JWT" \
        -H "Content-Type: application/json" \
        -d "{\"role\":\"viewer\",\"resource\":\"gw-reports\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
    check_status "Create policy via gateway (viewer → 403)" "403" "$STATUS"

    # ── 10e: Auth check via gateway ──────────────────────────────────────────
    # The gateway ext-authz uses x-authz-resource=auth / x-authz-action=read
    # for the auth/check route; OPA denies viewer for auth:read (not in
    # role_mappings).  Use tenant_admin so ext-authz passes, then verify OPA
    # correctly evaluates the inner documents:read check as ALLOW.
    STATUS=$(http POST "$GATEWAY_URL/api/v1/auth/check" \
        -H "Authorization: Bearer $ADMIN_JWT" \
        -H "Content-Type: application/json" \
        -d "{\"resource\":\"documents\",\"action\":\"read\",\"tenant_id\":\"$TENANT_ID\"}")
    check_status "Auth check via gateway (tenant_admin, HTTP 200)" "200" "$STATUS"
    decision=$(json_field 'd.get("allowed",False)')
    if [ "$decision" = "True" ]; then
        pass "Auth check via gateway → ALLOW"
    else
        fail "Auth check via gateway → expected ALLOW, got $decision"
    fi

    # cleanup gateway-created policy
    http DELETE "$GATEWAY_URL/api/v1/policies/role/${GW_POLICY_ID}?tenant_id=$TENANT_ID" \
        -H "Authorization: Bearer $ADMIN_JWT" >/dev/null
else
    info "Gateway tests skipped – run with TEST_GATEWAY=true ./test.sh to enable."
fi


# ===========================================================================
# Summary
# ===========================================================================
echo ""
if [ "$EXIT_CODE" -eq 0 ]; then
    echo -e "${GREEN}All tests passed!${NC}"
else
    echo -e "${RED}Some tests FAILED – review output above.${NC}"
fi
exit $EXIT_CODE
