# bundle-server/app/main.py
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import os
import json
import tarfile
import io
from datetime import datetime
import logging
import aiofiles
import httpx
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Bundle Server")

# Configuration
BASE_PATH = "/app/data"
TENANTS_PATH = os.path.join(BASE_PATH, "tenants")
BUNDLES_PATH = "/app/bundles"
OPAL_SERVER_URL = os.getenv("OPAL_SERVER_URL", "http://opal-server:7002")
OPAL_SERVER_TOKEN = os.getenv("OPAL_SERVER_TOKEN", "opal-server-token")
BUNDLE_SERVER_SELF_URL = os.getenv("BUNDLE_SERVER_SELF_URL", "http://bundle-server:8001")
# OPA REST API – used to push policies and data directly (no polling delay)
OPA_URL = os.getenv("OPA_URL", "http://localhost:8181")

os.makedirs(TENANTS_PATH, exist_ok=True)
os.makedirs(BUNDLES_PATH, exist_ok=True)


class ActionType(str, Enum):
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    LIST = "list"


class PolicyData(BaseModel):
    id: str
    role: str
    resource: str
    action: ActionType
    tenant_id: str
    conditions: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class NotifyRequest(BaseModel):
    tenant_id: str
    event: str
    policy_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

@app.on_event("startup")
async def startup_event():
    logger.info("Bundle Server starting up...")
    tenants = _list_tenants_sync()
    for tenant_id in tenants:
        await generate_tenant_bundle(tenant_id)
        tenant_data = await _build_tenant_data(tenant_id)
        await _push_to_opa(tenant_id, tenant_data)
    # Always push the combined Rego policy to OPA (even with 0 tenants),
    # so the authz/allow rule exists and returns a proper decision.
    await _push_default_policy_to_opa()
    await _rebuild_combined_bundle()
    logger.info("Initialized and pushed policies for %d tenants", len(tenants))


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "bundle-server",
        "tenants": len(_list_tenants_sync()),
        "timestamp": datetime.utcnow().isoformat(),
    }


# ---------------------------------------------------------------------------
# Tenant / policy CRUD
# ---------------------------------------------------------------------------

def _list_tenants_sync() -> List[str]:
    if not os.path.exists(TENANTS_PATH):
        return []
    return [
        d for d in os.listdir(TENANTS_PATH)
        if os.path.isdir(os.path.join(TENANTS_PATH, d))
    ]


@app.get("/api/v1/tenants")
async def list_tenants() -> List[str]:
    return _list_tenants_sync()


@app.get("/api/v1/tenants/{tenant_id}/policies")
async def get_tenant_policies(tenant_id: str) -> List[PolicyData]:
    tenant_dir = os.path.join(TENANTS_PATH, tenant_id)
    if not os.path.exists(tenant_dir):
        return []

    policies = []
    for filename in os.listdir(tenant_dir):
        if filename.endswith(".json"):
            async with aiofiles.open(os.path.join(tenant_dir, filename)) as f:
                policies.append(json.loads(await f.read()))
    return policies


@app.post("/api/v1/policies")
async def create_policy(policy: PolicyData, background_tasks: BackgroundTasks):
    tenant_dir = os.path.join(TENANTS_PATH, policy.tenant_id)
    os.makedirs(tenant_dir, exist_ok=True)

    policy_id = f"{policy.role}_{policy.resource}_{policy.action.value}"
    policy.id = policy_id
    policy.created_at = datetime.utcnow().isoformat()
    policy.updated_at = policy.created_at

    async with aiofiles.open(os.path.join(tenant_dir, f"{policy_id}.json"), "w") as f:
        await f.write(json.dumps(policy.dict(), indent=2))

    background_tasks.add_task(generate_and_notify, policy.tenant_id)
    return {"status": "success", "policy_id": policy_id, "tenant_id": policy.tenant_id}


@app.put("/api/v1/policies/{policy_id}")
async def update_policy(
    policy_id: str, policy: PolicyData, background_tasks: BackgroundTasks
):
    file_path = os.path.join(TENANTS_PATH, policy.tenant_id, f"{policy_id}.json")
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Policy not found")

    policy.updated_at = datetime.utcnow().isoformat()
    async with aiofiles.open(file_path, "w") as f:
        await f.write(json.dumps(policy.dict(), indent=2))

    background_tasks.add_task(generate_and_notify, policy.tenant_id)
    return {"status": "success", "policy_id": policy_id}


@app.delete("/api/v1/policies/{policy_id}")
async def delete_policy(
    tenant_id: str, policy_id: str, background_tasks: BackgroundTasks
):
    file_path = os.path.join(TENANTS_PATH, tenant_id, f"{policy_id}.json")
    if os.path.exists(file_path):
        os.remove(file_path)
        background_tasks.add_task(generate_and_notify, tenant_id)
    return {"status": "success"}


# ---------------------------------------------------------------------------
# OPA bundle endpoint (consumed directly by OPA via OPAL_INLINE_OPA_CONFIG)
# ---------------------------------------------------------------------------

@app.get("/api/v1/opa-bundle")
async def get_opa_bundle():
    """Return the latest combined OPA bundle tar.gz for all tenants."""
    bundle_file = os.path.join(BUNDLES_PATH, "combined_bundle.tar.gz")
    if not os.path.exists(bundle_file):
        # Return an empty valid bundle on first call
        bundle_file = await _build_empty_bundle()

    return FileResponse(
        bundle_file,
        media_type="application/gzip",
        filename="bundle.tar.gz",
    )


# ---------------------------------------------------------------------------
# Data endpoint for OPAL Client data-source polling
# ---------------------------------------------------------------------------

@app.get("/api/v1/data")
async def get_all_data() -> Dict:
    """Return combined OPA data document for all tenants (OPAL data source)."""
    tenants = _list_tenants_sync()
    tenants_data: Dict[str, Any] = {}
    for tenant_id in tenants:
        tenants_data[tenant_id] = await _build_tenant_data(tenant_id)
    return {"tenants": tenants_data}


@app.get("/api/v1/data/{tenant_id}")
async def get_tenant_data(tenant_id: str) -> Dict:
    """Return OPA data for a single tenant (OPAL data source per-tenant)."""
    return {"tenants": {tenant_id: await _build_tenant_data(tenant_id)}}


# ---------------------------------------------------------------------------
# OPAL notification (called by pep-proxy after saving a policy)
# ---------------------------------------------------------------------------

@app.post("/api/v1/notify")
async def notify_update(notify: NotifyRequest):
    """Receive policy-update notification, regenerate bundle, push to OPAL Server."""
    logger.info("Received policy notification: %s", notify)
    await generate_and_notify(notify.tenant_id)
    return {"status": "notified"}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

async def generate_and_notify(tenant_id: str):
    try:
        await generate_tenant_bundle(tenant_id)
        await _rebuild_combined_bundle()
        tenant_data = await _build_tenant_data(tenant_id)
        # Push directly to OPA via REST API – immediate, no polling delay needed
        await _push_to_opa(tenant_id, tenant_data)
        # Also tell OPAL Server so other OPAL Clients receive the update
        await _push_data_update_to_opal(tenant_id)
        logger.info("Policy pushed to OPA and OPAL notified for tenant %s", tenant_id)
    except Exception as e:
        logger.error("Failed to regenerate bundle for tenant %s: %s", tenant_id, e)


async def _build_tenant_data(tenant_id: str) -> Dict:
    """Build the role_mappings data structure for a tenant."""
    policies = await get_tenant_policies(tenant_id)
    role_mappings: Dict[str, Dict[str, List[str]]] = {}
    for policy in policies:
        role = policy["role"]
        resource = policy["resource"]
        action = policy["action"]
        role_mappings.setdefault(role, {}).setdefault(resource, [])
        if action not in role_mappings[role][resource]:
            role_mappings[role][resource].append(action)
    return {"role_mappings": role_mappings, "policies": policies}


async def generate_tenant_bundle(tenant_id: str) -> str:
    """Generate an OPA-compatible bundle tar.gz for a single tenant."""
    tenant_data = await _build_tenant_data(tenant_id)
    rego_policy = _generate_rego_policy(tenant_id, tenant_data)

    bundle_dir = os.path.join(BUNDLES_PATH, tenant_id)
    os.makedirs(bundle_dir, exist_ok=True)

    # Write data.json
    with open(os.path.join(bundle_dir, "data.json"), "w") as f:
        json.dump({"tenants": {tenant_id: tenant_data}}, f)

    # Write Rego policy
    policy_dir = os.path.join(bundle_dir, "authz")
    os.makedirs(policy_dir, exist_ok=True)
    with open(os.path.join(policy_dir, "policy.rego"), "w") as f:
        f.write(rego_policy)

    # Write OPA .manifest
    with open(os.path.join(bundle_dir, ".manifest"), "w") as f:
        json.dump({"revision": datetime.utcnow().isoformat(), "roots": ["authz"]}, f)

    # Build bundle tar.gz
    bundle_file = os.path.join(BUNDLES_PATH, f"{tenant_id}_bundle.tar.gz")
    with tarfile.open(bundle_file, "w:gz") as tar:
        tar.add(os.path.join(bundle_dir, ".manifest"), arcname=".manifest")
        tar.add(os.path.join(bundle_dir, "data.json"), arcname="data.json")
        tar.add(policy_dir, arcname="authz")

    return bundle_file


async def _rebuild_combined_bundle():
    """Rebuild the combined bundle from all tenant bundles."""
    tenants = _list_tenants_sync()
    combined_data: Dict[str, Any] = {"tenants": {}}
    rego_modules: Dict[str, str] = {}

    for tenant_id in tenants:
        tenant_data = await _build_tenant_data(tenant_id)
        combined_data["tenants"][tenant_id] = tenant_data
        rego_modules[tenant_id] = _generate_rego_policy(tenant_id, tenant_data)

    combined_bundle = os.path.join(BUNDLES_PATH, "combined_bundle.tar.gz")
    with tarfile.open(combined_bundle, "w:gz") as tar:
        # .manifest
        manifest = json.dumps({
            "revision": datetime.utcnow().isoformat(),
            "roots": ["authz"],
        }).encode()
        info = tarfile.TarInfo(name=".manifest")
        info.size = len(manifest)
        tar.addfile(info, io.BytesIO(manifest))

        # data.json
        data_bytes = json.dumps(combined_data).encode()
        info = tarfile.TarInfo(name="data.json")
        info.size = len(data_bytes)
        tar.addfile(info, io.BytesIO(data_bytes))

        # Rego policies per tenant
        for tenant_id, rego in rego_modules.items():
            rego_bytes = rego.encode()
            info = tarfile.TarInfo(name=f"authz/{tenant_id}.rego")
            info.size = len(rego_bytes)
            tar.addfile(info, io.BytesIO(rego_bytes))


async def _build_empty_bundle() -> str:
    """Build a minimal valid OPA bundle when no tenants exist yet."""
    bundle_file = os.path.join(BUNDLES_PATH, "combined_bundle.tar.gz")
    with tarfile.open(bundle_file, "w:gz") as tar:
        manifest = json.dumps({"revision": "empty", "roots": ["authz"]}).encode()
        info = tarfile.TarInfo(name=".manifest")
        info.size = len(manifest)
        tar.addfile(info, io.BytesIO(manifest))
    return bundle_file


def _generate_rego_policy(tenant_id: str, tenant_data: Dict) -> str:
    """
    Generate a Rego policy for a tenant that supports three role tiers:
      - super_admin  : unrestricted access (no tenant scope check)
      - tenant_admin : full access within their tenant
      - normal_user  : access governed by role_mappings configured by tenant_admin

    OPA verifies the JWT via OIDC using the iss claim to construct the
    per-tenant JWKS URL: {iss}/protocol/certs
    """
    return f"""package authz

import future.keywords

default allow = false

# ---------------------------------------------------------------------------
# JWT verification via OIDC (per-tenant JWKS URL derived from iss claim)
# ---------------------------------------------------------------------------

# Step 1: decode without verification to read the issuer (iss)
_raw_claims := claims {{
    [_, claims, _] := io.jwt.decode(input.token)
}}

# Step 2: derive the per-tenant JWKS URL directly from the iss claim.
# Expected iss format: {{OIDC_BASE_URL}}/tenants/{{tenant_id}}
# Keycloak exposes JWKS at {{iss}}/protocol/certs.
_jwks_url := url {{
    iss := _raw_claims.iss
    iss != ""
    url := concat("", [iss, "/protocol/certs"])
}}

# Step 3: verify signature and extract verified claims
_verified_claims := claims {{
    [valid, _, claims] := io.jwt.decode_verify(input.token, {{"jwks_url": _jwks_url}})
    valid
}}

# When OIDC is not configured (dev mode), fall back to unverified claims
_claims := _verified_claims
_claims := _raw_claims {{ not _jwks_url }}

# ---------------------------------------------------------------------------
# Tenant helpers (extracted from iss: {{base}}/realms/{{tenant_id}})
# ---------------------------------------------------------------------------

_user_roles  := _claims.roles

# Extract tenant_id from iss by splitting on "/realms/"; fall back to
# the tenant_id claim when iss does not follow the Keycloak pattern.
_user_tenant := t {{
    iss    := _claims.iss
    contains(iss, "/realms/")
    parts  := split(iss, "/realms/")
    segs   := split(parts[1], "/")
    t      := segs[0]
    t != ""
}} else := _claims.tenant_id

# super_admin bypasses all tenant and resource checks
allow {{
    "super_admin" in _user_roles
}}

# tenant_admin: full access within their own tenant,
# except realm management (create/delete tenants) which is super_admin only.
# target_tenant ensures the URL path realm matches the user's own tenant.
allow {{
    _user_tenant == "{tenant_id}"
    "tenant_admin" in _user_roles
    input.tenant_id == "{tenant_id}"
    input.target_tenant == "{tenant_id}"
    not _is_realm_management
}}

_is_realm_management {{
    input.resource == "tenants"
    input.action in ["create", "delete"]
}}

# normal_user: access governed by policy configured by tenant_admin.
# target_tenant ensures cross-tenant URL access is blocked.
allow {{
    _user_tenant == "{tenant_id}"
    input.tenant_id == "{tenant_id}"
    input.target_tenant == "{tenant_id}"
    role := _user_roles[_]
    resource_actions := data.tenants["{tenant_id}"].role_mappings[role][input.resource]
    input.action in resource_actions
}}

# resource_owner: explicit ownership check (optional, data-driven)
allow {{
    _user_tenant == "{tenant_id}"
    input.tenant_id == "{tenant_id}"
    input.target_tenant == "{tenant_id}"
    owner := data.tenants["{tenant_id}"].resource_owners[input.resource]
    _claims.sub == owner
}}
"""


def _generate_combined_rego() -> str:
    """
    Generate a SINGLE tenant-agnostic Rego policy for the authz package.

    All tenant-specific permissions live in data.tenants[tenant_id].role_mappings,
    so one module handles all tenants without per-tenant hardcoding.
    This avoids OPA "complete rule conflict" errors that occur when multiple
    modules with the same package name each define the same rules.

    JWT tenant is extracted from the iss claim: {base}/realms/{tenant_id} (Keycloak format)
    JWKS URL: {iss}/protocol/certs
    """
    return f"""package authz

import future.keywords

default allow = false

# ---------------------------------------------------------------------------
# JWT verification via OIDC (per-tenant JWKS URL derived from iss claim)
# ---------------------------------------------------------------------------

_raw_claims := claims {{
    [_, claims, _] := io.jwt.decode(input.token)
}}

# Derive per-tenant JWKS URL from the iss claim.
# iss = {{OIDC_BASE_URL}}/tenants/{{tenant_id}}  → JWKS at {{iss}}/protocol/certs
_jwks_url := url {{
    iss := _raw_claims.iss
    iss != ""
    url := concat("", [iss, "/protocol/certs"])
}}

_verified_claims := claims {{
    [valid, _, claims] := io.jwt.decode_verify(input.token, {{"jwks_url": _jwks_url}})
    valid
}}

# Use verified claims when OIDC JWKS is reachable; fall back to unverified
# raw claims when JWKS is unavailable (dev / HS256 mode).
# pep-proxy already validates the JWT signature before calling OPA, so
# falling back to unverified claims is safe in the development environment.
_claims := _verified_claims
_claims := _raw_claims {{ not _verified_claims }}

# Roles: use pre-extracted roles from input (pep-proxy gRPC handler extracts
# from realm_access.roles). Fall back to JWT claims for direct OPA queries.
_user_roles := input.roles {{ count(input.roles) > 0 }}
_user_roles := _claims.realm_access.roles {{ not input.roles; _claims.realm_access }}
_user_roles := _claims.roles {{ not input.roles; not _claims.realm_access; _claims }}

# Tenant: extract from Keycloak iss ({{base}}/realms/{{tenant_id}}),
# fall back to tenant_id claim, then to pre-decoded input.tenant_id.
_user_tenant_from_jwt := t {{
    iss    := _claims.iss
    contains(iss, "/realms/")
    parts  := split(iss, "/realms/")
    segs   := split(parts[1], "/")
    t      := segs[0]
    t != ""
}} else := _claims.tenant_id
_user_tenant := _user_tenant_from_jwt {{ _claims }}
_user_tenant := input.tenant_id       {{ not _claims }}

# ---------------------------------------------------------------------------
# Three-tier role hierarchy
# ---------------------------------------------------------------------------

# super_admin: unrestricted cross-tenant access
allow {{
    "super_admin" in _user_roles
}}

# tenant_admin: full access within their own tenant,
# except realm management (create/delete tenants) which is super_admin only.
# target_tenant ensures the URL path realm matches the user's own tenant.
allow {{
    _user_tenant != ""
    "tenant_admin" in _user_roles
    input.tenant_id == _user_tenant
    input.target_tenant == _user_tenant
    not _is_realm_management
}}

# Realm management: creating or deleting tenants/realms (super_admin only)
_is_realm_management {{
    input.resource == "tenants"
    input.action in ["create", "delete"]
}}

# normal_user: access governed by role_mappings set by tenant_admin.
# target_tenant ensures cross-tenant URL access is blocked.
allow {{
    _user_tenant != ""
    input.tenant_id == _user_tenant
    input.target_tenant == _user_tenant
    role := _user_roles[_]
    resource_actions := data.tenants[_user_tenant].role_mappings[role][input.resource]
    input.action in resource_actions
}}

# resource_owner: explicit ownership check (data-driven, optional)
allow {{
    _user_tenant != ""
    input.tenant_id == _user_tenant
    input.target_tenant == _user_tenant
    owner := data.tenants[_user_tenant].resource_owners[input.resource]
    _claims.sub == owner
}}
"""


async def _push_default_policy_to_opa():
    """Push the combined Rego policy to OPA even when no tenants exist yet."""
    try:
        rego = _generate_combined_rego()
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.put(
                f"{OPA_URL}/v1/policies/authz_main",
                content=rego.encode(),
                headers={"Content-Type": "text/plain"},
            )
            if resp.status_code in (200, 204):
                logger.info("Default combined Rego policy pushed to OPA")
            else:
                logger.error("OPA rejected default policy: %s – %s", resp.status_code, resp.text)
    except Exception as e:
        logger.error("Failed to push default policy to OPA: %s", e)


async def _push_to_opa(tenant_id: str, tenant_data: Dict):
    """
    Push the combined Rego policy and per-tenant data to OPA via REST API.

    Uses a SINGLE 'authz_main' policy module shared across all tenants.
    Per-tenant permissions live in data.tenants[tenant_id] (pushed separately).

    OPA REST API:
      PUT /v1/policies/authz_main        – load / replace the shared Rego module
      PUT /v1/data/tenants/{tenant_id}   – replace this tenant's data document
    """
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            # Push the shared combined Rego (idempotent overwrite)
            rego = _generate_combined_rego()
            policy_resp = await client.put(
                f"{OPA_URL}/v1/policies/authz_main",
                content=rego.encode(),
                headers={"Content-Type": "text/plain"},
            )
            if policy_resp.status_code not in (200, 204):
                logger.error(
                    "OPA rejected policy: %s – %s",
                    policy_resp.status_code, policy_resp.text,
                )

            # Push per-tenant data
            data_resp = await client.put(
                f"{OPA_URL}/v1/data/tenants/{tenant_id}",
                json=tenant_data,
            )
            if data_resp.status_code not in (200, 204):
                logger.error(
                    "OPA rejected data for tenant %s: %s – %s",
                    tenant_id, data_resp.status_code, data_resp.text,
                )

        logger.info("Pushed combined Rego + data to OPA for tenant %s", tenant_id)
    except Exception as e:
        logger.error("Failed to push to OPA for tenant %s: %s", tenant_id, e)


async def _push_data_update_to_opal(tenant_id: str):
    """
    Notify OPAL Server to push a data-update event to all connected OPAL Clients.
    Uses POST /v1/data/config which both registers the data source and triggers
    an immediate re-fetch by clients.
    """
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            await client.post(
                f"{OPAL_SERVER_URL}/v1/data/config",
                headers={"Authorization": f"Bearer {OPAL_SERVER_TOKEN}"},
                json={
                    "entries": [
                        {
                            "url": f"{BUNDLE_SERVER_SELF_URL}/api/v1/data/{tenant_id}",
                            "topics": ["policy_data"],
                            "dst_path": f"/tenants/{tenant_id}",
                        }
                    ],
                    "reason": f"Policy updated for tenant {tenant_id}",
                },
            )
    except Exception as e:
        logger.error("Failed to notify OPAL Server: %s", e)
