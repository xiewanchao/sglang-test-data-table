# app/auth.py
import os
import time
import logging
import httpx
from jose import jwt, jwk
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Dict, Any, Tuple, Optional

security = HTTPBearer()
logger = logging.getLogger(__name__)

# OIDC base URL – used to validate that the token issuer belongs to this IdP.
# e.g. https://auth.example.com
# Expected issuer format: {OIDC_BASE_URL}/realms/{tenant_id}
# OIDC discovery per-tenant: {iss}/.well-known/openid-configuration
# JWKS URI: extracted from discovery doc (typically {iss}/protocol/certs)
OIDC_BASE_URL = os.getenv("OIDC_BASE_URL", "")
# Internal Keycloak URL for OIDC discovery (when token iss uses a public hostname)
OIDC_INTERNAL_URL = os.getenv("OIDC_INTERNAL_URL", OIDC_BASE_URL)

# Fallback shared secret for HS256 (dev / testing only)
JWT_SECRET = os.getenv("JWT_SECRET", "")

# Simple in-memory JWKS cache: iss -> (jwks_data, expiry_timestamp)
_jwks_cache: Dict[str, Tuple[dict, float]] = {}
JWKS_CACHE_TTL = 300  # seconds


def _extract_tenant_from_issuer(iss: str) -> str:
    """
    Extract tenant_id from an issuer URL.

    Expected format: {base}/realms/{tenant_id}[/...]
    Example: https://auth.example.com/realms/tenant-001
             → tenant-001
    Returns empty string if the iss does not contain /realms/.
    """
    if "/realms/" in iss:
        tail = iss.split("/realms/", 1)[1]
        return tail.split("/")[0]
    return ""


def _decode_unverified(token: str) -> Optional[Dict[str, Any]]:
    """
    Decode a JWT without verifying the signature.
    Returns the claims dict, or None on any parse error.
    Used by the gRPC ext-authz server when agentgateway pre-verification
    metadata is unavailable.
    """
    try:
        return jwt.get_unverified_claims(token)
    except Exception:
        return None


async def _fetch_jwks(iss: str) -> dict:
    """
    Fetch JWKS for a specific token issuer via OIDC discovery.

    1. GET {iss}/.well-known/openid-configuration
    2. Extract jwks_uri from the discovery document.
    3. GET {jwks_uri} to obtain the JWKS.
    Results are cached per issuer for JWKS_CACHE_TTL seconds.
    """
    cached = _jwks_cache.get(iss)
    if cached and time.monotonic() < cached[1]:
        return cached[0]

    discovery_url = f"{iss}/.well-known/openid-configuration"
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            disc_resp = await client.get(discovery_url)
            disc_resp.raise_for_status()
            jwks_uri: Optional[str] = disc_resp.json().get("jwks_uri")
            if not jwks_uri:
                raise ValueError("jwks_uri missing from OIDC discovery document")

            jwks_resp = await client.get(jwks_uri)
            jwks_resp.raise_for_status()
            jwks = jwks_resp.json()

    except Exception as e:
        logger.error("Failed to fetch JWKS for issuer %s: %s", iss, e)
        raise HTTPException(status_code=401, detail="Unable to fetch signing keys")

    _jwks_cache[iss] = (jwks, time.monotonic() + JWKS_CACHE_TTL)
    return jwks


async def verify_token(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> Dict[str, Any]:
    """
    Verify a JWT Bearer token.

    Flow:
    1. Decode header + claims WITHOUT signature verification.
    2. Extract tenant_id from the iss (issuer) claim:
         iss = {OIDC_BASE_URL}/tenants/{tenant_id}
    3. Use iss as the OIDC discovery base to fetch the per-tenant JWKS.
    4. Verify the token signature using the RSA public key (RS256).
    5. Fall back to HS256 with JWT_SECRET when OIDC_BASE_URL is not set
       (development / testing). In fallback mode tenant_id is read from
       the tenant_id claim directly.
    """
    token = credentials.credentials

    # Step 1 – read header / claims without verifying signature
    try:
        unverified_header = jwt.get_unverified_header(token)
        unverified_claims = jwt.get_unverified_claims(token)
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Malformed token: {e}")

    algorithm: str = unverified_header.get("alg", "RS256")

    try:
        if algorithm.startswith("RS") and OIDC_BASE_URL:
            # Step 2 – extract tenant_id from iss claim
            iss: str = unverified_claims.get("iss", "")
            if not iss:
                raise HTTPException(status_code=401, detail="Missing iss claim in token")

            # Accept tokens whose iss matches either the public or internal URL
            if not (iss.startswith(OIDC_BASE_URL) or iss.startswith(OIDC_INTERNAL_URL)):
                raise HTTPException(
                    status_code=401,
                    detail=f"Token issuer does not match OIDC_BASE_URL: {iss}",
                )

            tenant_id = _extract_tenant_from_issuer(iss)
            if not tenant_id:
                raise HTTPException(
                    status_code=401,
                    detail=f"Cannot extract tenant_id from issuer: {iss}",
                )

            # Rewrite issuer to internal URL for OIDC discovery if needed
            discovery_iss = iss
            if OIDC_INTERNAL_URL and OIDC_INTERNAL_URL != OIDC_BASE_URL:
                # Replace public base with internal base for discovery
                discovery_iss = OIDC_INTERNAL_URL + iss[len(OIDC_BASE_URL):] if iss.startswith(OIDC_BASE_URL) else iss

            # Step 3-4 – OIDC discovery and JWKS verification
            jwks = await _fetch_jwks(discovery_iss)
            kid = unverified_header.get("kid")

            # Find the matching key; fall back to first key when no kid present
            key_data = next(
                (k for k in jwks.get("keys", []) if not kid or k.get("kid") == kid),
                None,
            )
            if key_data is None:
                raise HTTPException(
                    status_code=401, detail="Signing key not found in JWKS"
                )

            public_key = jwk.construct(key_data)
            payload = jwt.decode(
                token,
                public_key.to_pem().decode(),
                algorithms=[algorithm],
                options={"verify_aud": False},
            )

        elif JWT_SECRET:
            # Step 5 – HS256 fallback for dev / testing
            payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
            # In dev mode derive tenant from iss if present, else from tenant_id claim
            iss = payload.get("iss", "")
            tenant_id = _extract_tenant_from_issuer(iss) or payload.get("tenant_id", "")
            if tenant_id:
                payload["tenant_id"] = tenant_id

        else:
            raise HTTPException(
                status_code=401,
                detail="No verification key configured (set OIDC_BASE_URL or JWT_SECRET)",
            )

    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTClaimsError as e:
        raise HTTPException(status_code=401, detail=f"Invalid claims: {e}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Authentication failed: {e}")

    # Validate required claims
    if "sub" not in payload:
        raise HTTPException(status_code=401, detail="Missing required field in token: sub")

    # Extract tenant_id from iss (Keycloak format: {base}/realms/{tenant_id})
    if "tenant_id" not in payload:
        iss_val = payload.get("iss", "")
        extracted_tenant = _extract_tenant_from_issuer(iss_val) if iss_val else ""
        if extracted_tenant:
            payload["tenant_id"] = extracted_tenant
        else:
            raise HTTPException(status_code=401, detail="Missing required field in token: tenant_id")

    # Extract roles from Keycloak realm_access.roles if flat roles not present
    if "roles" not in payload:
        realm_access = payload.get("realm_access", {})
        kc_roles = realm_access.get("roles", [])
        if kc_roles:
            payload["roles"] = kc_roles
        else:
            payload["roles"] = []

    return {
        "user_id": payload["sub"],
        "tenant_id": payload["tenant_id"],
        "roles": payload["roles"],
        "email": payload.get("email", ""),
        "name": payload.get("name", ""),
        # Raw token forwarded to OPA so it can perform its own OIDC verification
        "token": token,
    }
