# app/models.py
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from enum import Enum

class ActionType(str, Enum):
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    LIST = "list"

class PolicyRequest(BaseModel):
    role: str
    resource: str
    action: ActionType
    tenant_id: str
    conditions: Optional[Dict[str, Any]] = None

class AuthRequest(BaseModel):
    # token is NOT in the body – it comes from the Authorization: Bearer header.
    # verify_token dependency handles extraction and forwards raw JWT to OPA.
    resource: str
    action: ActionType
    tenant_id: str
    context: Optional[Dict[str, Any]] = None

class PolicyTemplate(BaseModel):
    name: str
    content: str
    parameters: Dict[str, str]

class AuthResponse(BaseModel):
    allowed: bool
    user: str
    tenant_id: str
    resource: str
    action: str
    reason: Optional[str] = None