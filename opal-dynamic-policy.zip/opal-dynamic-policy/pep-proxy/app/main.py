# app/main.py
from fastapi import FastAPI, HTTPException, Depends, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, Any, List
import asyncio
import httpx
import logging
import os
from datetime import datetime

# Strong reference to the gRPC background task — prevents GC from killing it.
# asyncio only holds *weak* refs to tasks; an unreferenced task can be
# collected mid-execution, silently closing the gRPC port.
_grpc_task: "asyncio.Task | None" = None

from .models import (
    PolicyRequest, AuthRequest, AuthResponse,
    PolicyTemplate, ActionType
)
from .auth import verify_token
from .storage import PolicyStorage
from . import grpc_server

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 创建应用
app = FastAPI(
    title="PEP Proxy Service",
    description="Policy Enforcement Point with Dynamic Policy Management",
    version="1.0.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 配置常量
OPA_URL = os.getenv("OPA_URL", "http://localhost:8181")
BUNDLE_SERVER_URL = os.getenv("BUNDLE_SERVER_URL", "http://bundle-server:8000")

# 初始化存储
storage = PolicyStorage()

# 预定义模板
PREDEFINED_TEMPLATES = {
    "resource_owner": """
        package authz.templates.resource_owner
        
        default allow = false
        
        allow {
            input.resource == "{{resource}}"
            input.action == "{{action}}"
            input.tenant_id == "{{tenant_id}}"
            input.user == data.users["{{user_id}}"].id
        }
    """,
    
    "role_based": """
        package authz.templates.role_based
        
        default allow = false
        
        allow {
            input.resource == "{{resource}}"
            input.action == "{{action}}"
            input.tenant_id == "{{tenant_id}}"
            contains(input.roles[_], "{{role}}")
        }
    """,
    
    "tenant_admin": """
        package authz.templates.tenant_admin
        
        default allow = false
        
        allow {
            input.tenant_id == "{{tenant_id}}"
            contains(input.roles[_], "tenant_admin")
        }
    """
}

@app.on_event("startup")
async def startup_event():
    """启动时加载预定义模板，并启动 gRPC ext-authz 服务器"""
    global _grpc_task
    for name, content in PREDEFINED_TEMPLATES.items():
        await storage.save_template(name, content)
    logger.info(f"Loaded {len(PREDEFINED_TEMPLATES)} predefined templates")
    # Start gRPC ext-authz server on port 9000 (agentgateway integration).
    # Keep a strong reference so the task is not garbage-collected by the GC
    # (asyncio only holds weak refs; an unreferenced task silently disappears).
    _grpc_task = asyncio.create_task(grpc_server.serve())
    _grpc_task.add_done_callback(_on_grpc_task_done)


def _on_grpc_task_done(task: "asyncio.Task") -> None:
    """Log gRPC task exit — errors would otherwise be silently swallowed."""
    if task.cancelled():
        logger.warning("gRPC ext-authz task was cancelled")
    elif task.exception():
        logger.error("gRPC ext-authz task failed: %s", task.exception(), exc_info=task.exception())
    else:
        logger.info("gRPC ext-authz task finished cleanly")

@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "healthy",
        "service": "pep-proxy",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/auth/check", response_model=AuthResponse)
async def check_permission(
    request: AuthRequest,
    user_info: Dict = Depends(verify_token)
):
    """
    验证用户权限
    """
    try:
        # 构建OPA查询输入
        # "token" is the raw JWT; the Rego policy uses it for OIDC verification
        # via io.jwt.decode_verify with the per-tenant JWKS URL.
        opa_input = {
            "input": {
                "token": user_info["token"],
                "user": user_info["user_id"],
                "roles": user_info["roles"],
                "tenant_id": request.tenant_id,
                "resource": request.resource,
                "action": request.action,
                "context": request.context or {}
            }
        }
        
        # 调用OPA查询
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{OPA_URL}/v1/data/authz/allow",
                json=opa_input
            )
            
            if response.status_code != 200:
                logger.error(f"OPA query failed: {response.text}")
                raise HTTPException(
                    status_code=500,
                    detail="Authorization service error"
                )
            
            result = response.json()
            allowed = result.get("result", False)
            
            return AuthResponse(
                allowed=allowed,
                user=user_info["user_id"],
                tenant_id=request.tenant_id,
                resource=request.resource,
                action=request.action,
                reason="Allowed by policy" if allowed else "Denied by policy"
            )
            
    except httpx.RequestError as e:
        logger.error(f"OPA connection error: {e}")
        raise HTTPException(
            status_code=503,
            detail="Authorization service unavailable"
        )
    except Exception as e:
        logger.error(f"Permission check error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/policies/role")
async def create_role_policy(
    policy: PolicyRequest,
    user_info: Dict = Depends(verify_token)
):
    """
    创建基于角色的策略
    """
    # 验证租户管理员权限
    if "tenant_admin" not in user_info["roles"]:
        raise HTTPException(
            status_code=403,
            detail="Tenant admin access required"
        )
    
    # 验证租户ID匹配
    if policy.tenant_id != user_info["tenant_id"]:
        raise HTTPException(
            status_code=403,
            detail="Cannot create policy for other tenant"
        )
    
    try:
        # 保存策略
        policy_id = await storage.save_tenant_policy(
            user_info["tenant_id"],
            policy.dict()
        )
        
        # 通知Bundle Server更新
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{BUNDLE_SERVER_URL}/api/v1/notify",
                json={
                    "tenant_id": user_info["tenant_id"],
                    "event": "policy_updated",
                    "policy_id": policy_id
                }
            )
        
        return {
            "status": "success",
            "policy_id": policy_id,
            "message": "Policy created successfully",
            "tenant_id": user_info["tenant_id"]
        }
        
    except Exception as e:
        logger.error(f"Policy creation error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/ext-authz")
async def ext_authz_check(
    request: Request,
    user_info: Dict = Depends(verify_token),
):
    """
    Agentgateway-compatible External Authorization endpoint.

    Agentgateway calls this before routing any request to an MCP/tool backend.
    Resource and action are resolved in priority order:
      1. X-Authz-Resource / X-Authz-Action / X-Authz-Tenant-Id request headers
         (set explicitly by agentgateway routing rules per-backend)
      2. Derived from the original request path (X-Original-Path header,
         populated by agentgateway with the original inbound URL)

    Returns HTTP 200 + identity headers on ALLOW, HTTP 403 on DENY.
    """
    headers = request.headers

    # Tenant comes from the verified JWT (cannot be spoofed by the caller)
    tenant_id = user_info["tenant_id"]

    # Resource / action from explicit headers take precedence
    resource = headers.get("x-authz-resource", "")
    action   = headers.get("x-authz-action", "read")

    # Fall back: derive resource from the last path segment
    if not resource:
        original_path = headers.get("x-original-path", str(request.url.path))
        segments = [s for s in original_path.strip("/").split("/") if s]
        resource = segments[-1] if segments else "unknown"

    logger.info(
        "ext-authz: user=%s tenant=%s resource=%s action=%s",
        user_info["user_id"], tenant_id, resource, action,
    )

    opa_input = {
        "input": {
            "token": user_info["token"],
            "user": user_info["user_id"],
            "roles": user_info["roles"],
            "tenant_id": tenant_id,
            "resource": resource,
            "action": action,
            "context": {},
        }
    }

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{OPA_URL}/v1/data/authz/allow",
                json=opa_input,
            )
            if resp.status_code != 200:
                raise HTTPException(status_code=500, detail="OPA query failed")
            allowed = resp.json().get("result", False)

        if not allowed:
            raise HTTPException(status_code=403, detail="Forbidden by policy")

        # Return 200 with identity headers so the backend can consume them
        return Response(
            status_code=200,
            headers={
                "x-auth-user":   user_info["user_id"],
                "x-auth-tenant": tenant_id,
                "x-auth-roles":  ",".join(user_info["roles"]),
            },
        )

    except HTTPException:
        raise
    except httpx.RequestError as e:
        logger.error("OPA connection error in ext-authz: %s", e)
        raise HTTPException(status_code=503, detail="Authorization service unavailable")
    except Exception as e:
        logger.error("ext-authz error: %s", e)
        raise HTTPException(status_code=500, detail="Internal server error")


@app.get("/api/v1/policies")
async def list_policies(user_info: Dict = Depends(verify_token)):
    """List all policies for the authenticated user's tenant."""
    policies = await storage.get_tenant_policies(user_info["tenant_id"])
    return {
        "policies": policies,
        "count": len(policies),
        "tenant_id": user_info["tenant_id"],
    }


@app.put("/api/v1/policies/role/{policy_id}")
async def update_role_policy(
    policy_id: str,
    policy: PolicyRequest,
    user_info: Dict = Depends(verify_token),
):
    """Update an existing role-based policy (tenant_admin only)."""
    if "tenant_admin" not in user_info["roles"]:
        raise HTTPException(status_code=403, detail="Tenant admin access required")

    if policy.tenant_id != user_info["tenant_id"]:
        raise HTTPException(status_code=403, detail="Cannot update policy for other tenant")

    updated = await storage.update_tenant_policy(
        user_info["tenant_id"], policy_id, policy.dict()
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Policy not found")

    try:
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{BUNDLE_SERVER_URL}/api/v1/notify",
                json={
                    "tenant_id": user_info["tenant_id"],
                    "event": "policy_updated",
                    "policy_id": policy_id,
                },
            )
    except Exception as e:
        logger.error("Failed to notify bundle-server after update: %s", e)

    return {
        "status": "success",
        "policy_id": policy_id,
        "message": "Policy updated successfully",
        "tenant_id": user_info["tenant_id"],
    }


@app.delete("/api/v1/policies/role/{policy_id}")
async def delete_role_policy(
    policy_id: str,
    tenant_id: str,
    user_info: Dict = Depends(verify_token),
):
    """Delete a role-based policy (tenant_admin only). Pass tenant_id as query param."""
    if "tenant_admin" not in user_info["roles"]:
        raise HTTPException(status_code=403, detail="Tenant admin access required")

    if tenant_id != user_info["tenant_id"]:
        raise HTTPException(status_code=403, detail="Cannot delete policy for other tenant")

    deleted = await storage.delete_tenant_policy(user_info["tenant_id"], policy_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Policy not found")

    try:
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{BUNDLE_SERVER_URL}/api/v1/notify",
                json={
                    "tenant_id": user_info["tenant_id"],
                    "event": "policy_deleted",
                    "policy_id": policy_id,
                },
            )
    except Exception as e:
        logger.error("Failed to notify bundle-server after delete: %s", e)

    return {
        "status": "success",
        "policy_id": policy_id,
        "message": "Policy deleted successfully",
    }


@app.get("/api/v1/policies/templates")
async def list_templates(
    user_info: Dict = Depends(verify_token)
):
    """列出所有可用的策略模板"""
    templates = await storage.list_templates()
    return {
        "templates": templates,
        "count": len(templates)
    }

@app.post("/api/v1/policies/template/{template_name}")
async def create_policy_from_template(
    template_name: str,
    parameters: Dict[str, str],
    user_info: Dict = Depends(verify_token)
):
    """
    从模板创建策略
    """
    # 验证租户管理员权限
    if "tenant_admin" not in user_info["roles"]:
        raise HTTPException(
            status_code=403,
            detail="Tenant admin access required"
        )
    
    # 获取模板
    template_content = await storage.get_template(template_name)
    if not template_content:
        raise HTTPException(
            status_code=404,
            detail=f"Template {template_name} not found"
        )
    
    # 渲染模板
    try:
        for key, value in parameters.items():
            template_content = template_content.replace(f"{{{{{{{key}}}}}}}", value)
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Template rendering error: {str(e)}"
        )
    
    return {
        "status": "success",
        "template": template_name,
        "rendered_policy": template_content
    }