# 在 Agentgateway (K8s) 中集成 Keycloak + OPA 认证授权 — 完整教程（v11-localhost 版，无需 hosts 配置）

## 架构概览

### 三级 API 路径模型

```
前端应用 (浏览器)
    │
    │  ① 浏览器跳转登录（全部走 Gateway 代理到 Keycloak）
    │     http://localhost/realms/data-agent/protocol/openid-connect/auth?...
    │     SSH 隧道 + port-forward → Gateway → keycloak-route → Keycloak
    │     client: da-client (Public Client，无 secret)
    │
    ▼
Keycloak data-agent realm ──── Identity Brokering ────→ Huaxi Hospital realm
    │                          (联邦信任)                    (用户在这里登录)
    │
    │  ② 签发 JWT
    │     iss = http://localhost/realms/data-agent（frontchannel，固定）
    │     OPA 通过集群内地址直连 Keycloak 做 OIDC Discovery（backchannel，动态）
    │
    ▼
agentgateway-proxy
    │
    ├── HTTPRoute 路径匹配（Gateway 层路由分流）
    │       ├── /realms/*                             → keycloak-route（无 auth，裸透传）
    │       ├── /resources/*                          → keycloak-static-route（无 auth，Keycloak 静态资源）
    │       ├── /admin/*                              → keycloak-admin-route（无 auth，Keycloak 管理控制台）
    │       ├── /data-agent/super-admin/*              → super-admin-route（需 auth）
    │       └── /*（其他所有路径）                      → tenant-api-route（需 auth）
    │
    ├── extAuth → OPA（仅挂在 super-admin-route 和 tenant-api-route）
    │       ├── 从 Authorization header 提取 JWT
    │       ├── io.jwt.decode 解码获取 iss
    │       ├── 校验 iss 在可信白名单中
    │       ├── OIDC Discovery: 直接用集群内地址访问 Keycloak
    │       │   （backchannel-dynamic 使 JWKS URI 等返回集群内地址）
    │       ├── GET {jwks_uri} → 获取 JWKS 公钥（缓存 1 小时）
    │       ├── io.jwt.verify_rs256 验签 + 校验 exp/nbf
    │       ├── 验签失败 → deny（返回 403）
    │       ├── 提取 realm_access.roles + 请求路径 → RBAC 判定
    │       ├── allow  → 注入 X-Auth-* Headers → 转发到后端
    │       └── deny   → 返回 403 Forbidden
    │
    ▼
httpbin（后端 mock 服务） / Keycloak（登录相关）
```

### 三级预置 API 路径

| 级别 | URL 模式 | 角色要求 | 说明 |
| --- | --- | --- | --- |
| **super-admin** | `http://{hostname}/data-agent/super-admin/{resource-path}` | `super_admin` | 全局超级管理员，跨租户管理 |
| **tenant-admin** | `http://{hostname}/{tenant-id}/data-agent/admin/{resource-path}` | `tenant_admin` | 租户管理员，管理本租户 |
| **normal-user** | `http://{hostname}/{tenant-id}/data-agent/{resource-path}` | `default-roles-data-agent` | 普通租户用户 |

> **路径设计说明**：
> - `{tenant-id}` 为租户标识，如 `huaxi`、`tenant-001` 等
> - super-admin 路径不包含 tenant-id，因为它是跨租户的全局管理接口
> - tenant-admin 和 normal-user 路径以 `/{tenant-id}/data-agent` 开头，通过有无 `/admin/` 子路径区分权限层级
> - Gateway 层使用 `PathPrefix` 将 super-admin 与其他路径分流；由于 agentgateway K8s 数据面不支持 `RegularExpression` 路径匹配，tenant 级路径的权限区分**完全交给 OPA**
> - OPA 在路径格式校验 + 角色校验双层面做 RBAC

### v11 与 v10 的核心区别

| 对比维度 | v10（简单 allow） | v11（结构化返回 + Header 注入） |
| --- | --- | --- |
| OPA 返回值 | `allow := true/false` | `allow := {"allowed": true/false, "headers": {...}}` |
| 后端收到的信息 | 仅知道请求通过了认证 | 收到 `X-Auth-*` Headers，包含用户身份信息 |
| 后端用户识别 | 需自行解析 JWT | 直接从 Header 读取用户 ID、角色等 |
| 决策路径 | `envoy/authz/allow` | `envoy/authz/allow`（变量名不变） |
| 其他 | 同 v10 | 同 v10 |

### OPA 注入的 X-Auth-* Headers

| Header | 来源 | 示例值 |
|--------|------|--------|
| `X-Auth-User-Id` | `payload.sub` | `f47ac10b-58cc-...` |
| `X-Auth-Username` | `payload.preferred_username` | `g-5e3f01eb-...` |
| `X-Auth-Roles` | `payload.realm_access.roles` | `tenant_admin,default-roles-data-agent` |
| `X-Auth-Email` | `payload.email` | `user@example.com` |
| `X-Auth-Issuer` | `payload.iss` | `http://localhost/realms/data-agent` |
| `X-Auth-Tenant-Id` | `payload.tenant_id`（如已配置） | `huaxi` |

> **后端收益**：后端服务无需引入 JWT 库，无需获取公钥验签，直接从请求 Header 中读取已验证的用户信息。OPA 已完成所有安全校验。

### v11 与 v8 的核心区别

| 对比维度 | v8（集群内 Issuer） | v11（backchannel-dynamic + Header 注入） |
| --- | --- | --- |
| `KC_HOSTNAME` | `http://keycloak.keycloak.svc.cluster.local:8080` | `http://localhost` |
| `KC_HOSTNAME_BACKCHANNEL_DYNAMIC` | 未设置 | `true` |
| JWT `iss` | 集群内地址（浏览器不可达） | `http://localhost/realms/data-agent` |
| 浏览器登录 | ❌ 不支持（已知限制） | ✅ 支持（Authorization Code Flow + PKCE） |
| Keycloak NodePort | 可选保留 | ✅ 已取消，全部走 Gateway 代理 |
| OPA OIDC Discovery | 用 issuer 地址（集群内，OPA 直达） | 用集群内地址直连（backchannel-dynamic 自动返回集群内端点） |
| OPA issuer 映射表 | 不需要 | **不需要** |
| OPA 返回值 | 简单布尔值 | 结构化对象（含 `X-Auth-*` Headers） |
| 后端用户信息 | 无 | 通过 `X-Auth-*` Headers 传递 |
| Dashboard | 仅 curl 测试 | ✅ 浏览器可直接使用，显示注入的 Headers |
| DNS 要求 | 无 | 无（localhost 无需额外 DNS 配置） |

### 为什么用角色而不是用户名做 RBAC？

联邦用户通过 Identity Brokering 登录到 `data-agent` realm 后，`preferred_username` 是自动生成的 UUID 格式（如 `g-96453fff-a49d-4703-aecc-a507e603fab5`），不可读且不稳定。而 `data-agent` realm 中已预配置了角色，直接用 `realm_access.roles` 做权限控制更合理。

### 核心设计理念

- **OPA 统一做 JWT 验签 + RBAC 授权 + Header 注入**（不使用 agentgateway 原生 jwtAuthentication）
- **`KC_HOSTNAME` 固定前端 issuer**，`hostname-backchannel-dynamic=true` 让 OPA 在集群内直连 Keycloak 时自动获得集群内端点地址
- **OPA 无需任何 issuer 映射表**，直接用集群内地址做 OIDC Discovery，Keycloak 自动返回集群内 jwks_uri
- **OPA 授权通过后，将用户身份信息注入 `X-Auth-*` Headers**，后端无需解析 JWT
- Keycloak 登录流量和管理控制台通过 Gateway 代理，**取消 Keycloak NodePort**，外部不直接暴露 Keycloak
- 使用 Public Client + Authorization Code Flow + PKCE，前端无需存储 secret
- ext_authz 策略挂到 HTTPRoute 级别，keycloak-route 无 auth
- 三级 API 路径清晰分离超管/租户管理/普通用户的权限边界

---

## 环境信息

| 组件 | 详情 |
| --- | --- |
| SP Realm（服务提供方） | `data-agent` |
| IdP Realm（身份提供方） | `Huaxi Hospital`（通过联邦信任连接） |
| IdP Broker 别名（alias） | `saml` |
| Gateway 域名 | `localhost`（无需额外 DNS/hosts 配置） |
| Gateway 端口 | `80`（port-forward，需 sudo） |
| Keycloak 集群内 Service | `keycloak.keycloak.svc.cluster.local:8080` |
| KC_HOSTNAME | `http://localhost` |
| KC_HOSTNAME_BACKCHANNEL_DYNAMIC | `true` |
| JWT issuer（前端固定） | `http://localhost/realms/data-agent` |
| OPA OIDC Discovery（集群内 backchannel） | `http://keycloak.keycloak.svc.cluster.local:8080/realms/data-agent/.well-known/openid-configuration` |
| 前端 Client（Public） | `da-client`（无 secret，用于前端 Authorization Code Flow） |
| 测试 Client（Confidential） | `sp-da-inner-client` / `ErulhvR0gmVF1rApfzOnhaurrGcAuiWW`（在 Huaxi Hospital realm，用于命令行快速测试） |
| 测试用户 | `test_1` / `Huawei@666`（在 Huaxi Hospital realm） |
| JWT preferred_username | `g-96453fff-...`（联邦用户自动生成的 UUID） |

---

## 前提条件

1. ✅ Kubernetes 集群 + agentgateway 控制面已安装
2. ✅ agentgateway-proxy Gateway 已创建
3. ✅ httpbin 已部署
4. ✅ Keycloak 部署在同一集群内（namespace: `keycloak`）
5. ✅ `data-agent` realm 已配置 SAML Identity Provider（alias: `saml`）联邦到 `Huaxi Hospital` realm
6. ✅ `da-client` Public Client 已在 `data-agent` realm 创建（standardFlowEnabled=true）
7. ✅ SSH 隧道已建立：`ssh -L 80:127.0.0.1:80 <k8s-server>`（端口 80 需 sudo）

---

## 第 0 步：本机环境准备

> **端口 80 说明**：本版使用 `localhost`（端口 80），省去了 hosts 文件配置。但 Linux/Mac 上 80 是特权端口，port-forward 和 SSH 隧道需 `sudo`。如果不想用 sudo，可改为高端口（如 8080），此时 `KC_HOSTNAME` 和所有 URL 需改为 `http://localhost:8080`。Windows 上通常无此限制。

### 0.1 K8s 服务器 port-forward

```bash
sudo -v
sudo -E kubectl port-forward svc/agentgateway-proxy -n agentgateway-system 80:80 --address 0.0.0.0 &
```

### 0.2 本机 SSH 隧道

```bash
sudo ssh -L 80:127.0.0.1:80 <k8s-server>
```

验证链路通畅：

```bash
curl -s http://localhost/
# 应收到响应（可能是 404 或其他，只要不是连接拒绝就说明链路通了）
```

---

## 第 1 步：配置 Keycloak hostname（backchannel-dynamic 模式）

v11 的核心配置：`KC_HOSTNAME` 固定前端 URL，`KC_HOSTNAME_BACKCHANNEL_DYNAMIC=true` 让集群内 backchannel 请求动态解析端点地址。

```bash
kubectl -n keycloak set env statefulset/keycloak \
  KC_HOSTNAME=http://localhost \
  KC_HOSTNAME_BACKCHANNEL_DYNAMIC=true \
  KC_PROXY_HEADERS=xforwarded \
  KC_HTTP_ENABLED=true

# 等待重启完成
kubectl rollout status statefulset/keycloak -n keycloak
```

> **参数说明**：
> - `KC_HOSTNAME=http://localhost`：固定前端 URL，Keycloak 签发的 token `iss`、登录页链接、redirect URL 全部使用此地址（使用默认 80 端口，URL 中无需显式写端口号）
> - `KC_HOSTNAME_BACKCHANNEL_DYNAMIC=true`：backchannel 端点（token endpoint、JWKS URI、userinfo 等）根据请求来源动态解析。OPA 从集群内访问时，拿到的 jwks_uri 等自动变为集群内地址
> - `KC_PROXY_HEADERS=xforwarded`：信任 Gateway 转发的 X-Forwarded-* 头
> - `KC_HTTP_ENABLED=true`：允许 HTTP（Gateway 和 Keycloak 之间走集群内 HTTP）

验证——浏览器端（frontchannel）：

```bash
curl -s http://localhost/realms/data-agent/.well-known/openid-configuration | jq '.issuer, .jwks_uri, .token_endpoint'
# 预期输出（全部是外部地址）:
# "http://localhost/realms/data-agent"
# "http://localhost/realms/data-agent/protocol/openid-connect/certs"
# "http://localhost/realms/data-agent/protocol/openid-connect/token"
```

验证——集群内（backchannel）：

```bash
kubectl run curl-test --rm -it --image=curlimages/curl --image-pull-policy=IfNotPresent --restart=Never -- \
  curl -s "http://keycloak.keycloak.svc.cluster.local:8080/realms/data-agent/.well-known/openid-configuration" 2>/dev/null | jq '.issuer, .jwks_uri, .token_endpoint'
# 预期输出（issuer 固定为前端地址，但 jwks_uri 和 token_endpoint 是集群内地址）:
# "http://localhost/realms/data-agent"
# "http://keycloak.keycloak.svc.cluster.local:8080/realms/data-agent/protocol/openid-connect/certs"
# "http://keycloak.keycloak.svc.cluster.local:8080/realms/data-agent/protocol/openid-connect/token"
```

> **这就是 `hostname-backchannel-dynamic=true` 的魔法**：issuer 始终固定为前端地址（安全），但 backchannel 端点根据请求来源动态返回集群内地址（OPA 可达）。OPA 无需任何 issuer 映射表。

---

## 第 2 步：取消 Keycloak NodePort（可选但推荐）

既然所有外部访问都通过 Gateway 代理，Keycloak Service 不再需要 NodePort 暴露。

```bash
kubectl -n keycloak patch svc keycloak -p '{"spec":{"type":"ClusterIP"}}'

# 验证
kubectl get svc -n keycloak keycloak
# TYPE 应为 ClusterIP
```

> Admin API 和管理控制台通过 Gateway 的 `keycloak-admin-route`（`/admin/*`）代理访问，浏览器可直接打开 `http://localhost/admin/master/console/`。也可通过 `kubectl port-forward -n keycloak svc/keycloak 9080:8080` 直连 Keycloak。

---

## 第 3 步：部署 HTTPRoute（四类路由）

v11 新增 `keycloak-static-route` 用于 Keycloak 登录页面的静态资源（CSS、JS、图片），路径为 `/resources/*`。同时新增 `keycloak-admin-route` 用于 Keycloak 管理控制台，路径为 `/admin/*`。

> **路由匹配优先级**：Gateway API 遵循最长前缀优先。
> - `/realms` 匹配 Keycloak OIDC 请求（长度 7）
> - `/resources` 匹配 Keycloak 静态资源（长度 10）
> - `/admin` 匹配 Keycloak 管理控制台（长度 6）
> - `/data-agent/super-admin` 匹配超管请求（长度 25）
> - `/` 兜底匹配其他所有请求（长度 1）

```bash
kubectl apply -f- <<'EOF'
apiVersion: gateway.networking.k8s.io/v1beta1
kind: ReferenceGrant
metadata:
  name: allow-routes-to-httpbin
  namespace: httpbin
spec:
  from:
  - group: gateway.networking.k8s.io
    kind: HTTPRoute
    namespace: agentgateway-system
  to:
  - group: ""
    kind: Service
    name: httpbin
---
apiVersion: gateway.networking.k8s.io/v1beta1
kind: ReferenceGrant
metadata:
  name: allow-routes-to-keycloak
  namespace: keycloak
spec:
  from:
  - group: gateway.networking.k8s.io
    kind: HTTPRoute
    namespace: agentgateway-system
  to:
  - group: ""
    kind: Service
    name: keycloak
---
# =============================================
# Keycloak OIDC 端点（无 auth）
# =============================================
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: keycloak-route
  namespace: agentgateway-system
spec:
  parentRefs:
  - name: agentgateway-proxy
    namespace: agentgateway-system
  hostnames:
  - "localhost"
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /realms
    backendRefs:
    - name: keycloak
      namespace: keycloak
      port: 8080
---
# =============================================
# Keycloak 静态资源（无 auth）
# =============================================
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: keycloak-static-route
  namespace: agentgateway-system
spec:
  parentRefs:
  - name: agentgateway-proxy
    namespace: agentgateway-system
  hostnames:
  - "localhost"
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /resources
    backendRefs:
    - name: keycloak
      namespace: keycloak
      port: 8080
---
# =============================================
# Keycloak 管理控制台（无 auth）
# =============================================
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: keycloak-admin-route
  namespace: agentgateway-system
spec:
  parentRefs:
  - name: agentgateway-proxy
    namespace: agentgateway-system
  hostnames:
  - "localhost"
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /admin
    backendRefs:
    - name: keycloak
      namespace: keycloak
      port: 8080
---
# =============================================
# super-admin 路由（需 auth）
# /super-admin/{resource}
# /super-admin/{app}/{resource}
# 全部转发到 httpbin，保留原始路径方便调试
# =============================================
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: super-admin-route
  namespace: agentgateway-system
spec:
  parentRefs:
  - name: agentgateway-proxy
    namespace: agentgateway-system
  hostnames:
  - "localhost"
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /super-admin
    filters:
    - type: URLRewrite
      urlRewrite:
        path:
          type: ReplacePrefixMatch
          replacePrefixMatch: /anything/super-admin
    backendRefs:
    - name: httpbin
      namespace: httpbin
      port: 8000
---
# =============================================
# 租户 API 兜底路由（需 auth）
# /{tenant-id}/{app}/{resource}              → normal-user
# /{tenant-id}/{app}/admin/{resource}        → tenant-admin
# OPA 负责路径解析、租户隔离、角色校验
# =============================================
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: tenant-api-route
  namespace: agentgateway-system
spec:
  parentRefs:
  - name: agentgateway-proxy
    namespace: agentgateway-system
  hostnames:
  - "localhost"
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /
    filters:
    - type: URLRewrite
      urlRewrite:
        path:
          type: ReplacePrefixMatch
          replacePrefixMatch: /anything
    backendRefs:
    - name: httpbin
      namespace: httpbin
      port: 8000
EOF
```

---

## 第 4 步：验证 Keycloak 路由可达

```bash
# OIDC Discovery（通过 Gateway）
curl -s http://localhost/realms/data-agent/.well-known/openid-configuration | jq '.issuer, .jwks_uri, .token_endpoint'
# 预期：issuer 为外部地址，jwks_uri/token_endpoint 也为外部地址（浏览器端 frontchannel）

# Keycloak 静态资源路由可达
curl -s -o /dev/null -w "%{http_code}" http://localhost/resources/
# 预期: 200 或 302

# Keycloak 管理控制台路由可达
curl -s -o /dev/null -w "%{http_code}" http://localhost/admin/master/console/
# 预期: 200 或 302（浏览器打开 http://localhost/admin/master/console/ 可直接访问管理界面）

# 业务路由可达（此时无 auth）
curl -i http://localhost/huaxi/data-agent/records
# 预期: 200 OK
```

---

## 第 5 步：获取并分析 Keycloak Token

### 5.1 通过 Confidential Client 快速获取 Token（curl 测试方式）

```bash
ACCESS_TOKEN=$(curl -s -X POST \
  "http://localhost/realms/data-agent/protocol/openid-connect/token" \
  -d "grant_type=password" \
  -d "client_id=sp-da-inner-client" \
  -d "client_secret=ErulhvR0gmVF1rApfzOnhaurrGcAuiWW" \
  -d "username=test_user" \
  -d "password=huawei@123" | jq -r '.access_token')

echo "✅ Token 获取成功：${ACCESS_TOKEN:0:50}..."
```

### 5.2 解码确认关键字段

```bash
echo $ACCESS_TOKEN | cut -d'.' -f2 | base64 --decode 2>/dev/null | jq '{
  iss, sub, aud, azp,
  preferred_username, email,
  realm_access, resource_access
}'
```

| 字段 | 实际值 | 说明 |
| --- | --- | --- |
| `iss` | `http://localhost/realms/data-agent` | 固定前端地址，OPA 白名单匹配 |
| `preferred_username` | `g-96453fff-...` | 联邦用户自动生成的 UUID |
| `aud` | `account` | — |
| `azp` | `sp-da-inner-client` | 授权的 client |
| `realm_access.roles` | `["default-roles-data-agent", "offline_access", "uma_authorization"]` | OPA 角色匹配 |

> **角色说明**：`data-agent` realm 中需配置以下三个核心角色：
> - `default-roles-data-agent`：所有联邦用户自动获得（访问普通租户接口）
> - `tenant_admin`：管理员手动分配（访问租户管理接口）
> - `super_admin`：超级管理员手动分配（访问全局超管接口）

---

## 第 6 步：确认 Keycloak 角色配置

`data-agent` realm 中需要以下角色，OPA 策略将基于这些角色做权限控制：

| 角色 | 获得方式 | 权限 |
| --- | --- | --- |
| `default-roles-data-agent` | 所有联邦用户**自动获得** | 可访问 `/{tenant-id}/data-agent/{resource}` |
| `tenant_admin` | 管理员**手动分配** | 可访问 `/{tenant-id}/data-agent/admin/{resource}` + 普通用户路径 |
| `super_admin` | 超级管理员**手动分配** | 可访问 `/data-agent/super-admin/{resource}` + 所有租户路径 |

### 6.1 查看现有角色

> **Admin API 访问说明**：Keycloak Admin API（`/admin/realms/...`）已通过 `keycloak-admin-route`（`/admin/*`）代理到 Keycloak。浏览器可直接访问 `http://localhost/admin/master/console/` 打开管理控制台。以下 curl 命令使用 port-forward 方式直连 Keycloak，也可以改为通过 Gateway 访问（将 `http://127.0.0.1:9080` 替换为 `http://localhost`）。

```bash
kubectl port-forward -n keycloak svc/keycloak 9080:8080 &

ADMIN_TOKEN=$(curl -s -X POST \
  "http://127.0.0.1:9080/realms/master/protocol/openid-connect/token" \
  -d "grant_type=password" \
  -d "client_id=admin-cli" \
  -d "username=admin" \
  -d "password=admin" | jq -r '.access_token')

curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
  "http://127.0.0.1:9080/admin/realms/data-agent/roles" | jq '.[].name'
```

### 6.2 创建新角色（如尚未创建）

```bash
curl -s -X POST \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  "http://127.0.0.1:9080/admin/realms/data-agent/roles" \
  -d '{"name": "super_admin", "description": "全局超级管理员，可跨租户管理"}' \
  && echo "✅ 已创建 super_admin 角色"

curl -s -X POST \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  "http://127.0.0.1:9080/admin/realms/data-agent/roles" \
  -d '{"name": "tenant_admin", "description": "租户管理员"}' \
  2>/dev/null; echo "✅ tenant_admin 角色已就绪"
```

### 6.3 查看联邦用户当前角色

```bash
USER_ID=$(curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
  "http://127.0.0.1:9080/admin/realms/data-agent/users?first=0&max=20" \
  | jq -r '.[] | select(.username | startswith("g-")) | .id')

curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
  "http://127.0.0.1:9080/admin/realms/data-agent/users/$USER_ID/role-mappings/realm" \
  | jq '.[].name'
```

### 6.4 为用户分配角色（按需）

```bash
# 分配 tenant_admin
ROLE_TENANT_ADMIN=$(curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
  "http://127.0.0.1:9080/admin/realms/data-agent/roles/tenant_admin")

curl -s -X POST \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  "http://127.0.0.1:9080/admin/realms/data-agent/users/$USER_ID/role-mappings/realm" \
  -d "[$ROLE_TENANT_ADMIN]" && echo "✅ 已分配 tenant_admin 角色"

# 分配 super_admin
ROLE_SUPER_ADMIN=$(curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
  "http://127.0.0.1:9080/admin/realms/data-agent/roles/super_admin")

curl -s -X POST \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  "http://127.0.0.1:9080/admin/realms/data-agent/users/$USER_ID/role-mappings/realm" \
  -d "[$ROLE_SUPER_ADMIN]" && echo "✅ 已分配 super_admin 角色"
```

> 分配角色后，用户需重新登录获取新 token 才能生效。

---

## 第 7 步：编写 OPA 策略（OIDC Discovery + 三级 RBAC + Header 注入）

OPA 统一完成 JWT 验签、RBAC 授权，并在授权通过后将用户身份信息注入 `X-Auth-*` Headers 转发给后端。

> **v11 核心改进**：OPA 返回结构化对象 `{"allowed": true/false, "headers": {...}}`，授权通过时将 JWT 中的用户信息（sub、username、roles、email 等）注入为请求 Header，后端无需自行解析 JWT。

> **v11 核心优势（继承自 v10）**：由于 `hostname-backchannel-dynamic=true`，OPA 从集群内访问 Keycloak OIDC Discovery 时，返回的 `jwks_uri` 等端点自动为集群内地址。**OPA 不需要任何 issuer 映射表**，直接用集群内地址做 Discovery 即可。但 token 的 `iss` 是固定的前端地址，OPA 白名单用前端地址。

> **缓存机制**：OPA 的 `http.send` 内建缓存，正常运行中每个请求 **0 次 HTTP 调用**，全部命中 OPA 进程内缓存。
> - OIDC Discovery metadata → 缓存 24 小时
> - JWKS 公钥 → 缓存 1 小时
> - 密钥轮换时 kid 不匹配会自动绕过缓存重新获取

```bash
kubectl apply -f- <<'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: opa-policy
  namespace: agentgateway-system
data:
  policy.rego: |
    package envoy.authz

    import input.attributes.request.http as http_request
    import future.keywords.if
    import future.keywords.in

    # ================================================================
    # 结构化返回
    # ================================================================
    default allow := {"allowed": false}

    # ================================================================
    # 集群内 Keycloak 基地址
    # ================================================================
    _keycloak_internal := "http://keycloak.keycloak.svc.cluster.local:8080"

    # ================================================================
    # 动态拼接集群内 Discovery 地址
    # ================================================================
    _discovery_issuer := concat("", [_keycloak_internal, _realm_path]) if {
        iss := _token_payload_unverified.iss
        parts := split(iss, "/")
        count(parts) >= 5
        parts[3] == "realms"
        _realm_path := concat("/", ["", "realms", parts[4]])
    }

    # ================================================================
    # 从 iss 提取 realm 名称
    # ================================================================
    _realm_name := parts[4] if {
        parts := split(_token_payload_unverified.iss, "/")
        count(parts) >= 5
        parts[3] == "realms"
    }

    # ================================================================
    # 从请求路径提取 tenant-id（第一段）
    # /huaxi/data-agent/records → huaxi
    # ================================================================
    _tenant_from_url := parts[1] if {
        parts := split(http_request.path, "/")
        count(parts) >= 3
        parts[1] != ""
    }

    # ================================================================
    # 租户隔离：URL tenant-id 必须等于 token realm
    # ================================================================
    _tenant_matches if {
        _tenant_from_url == _realm_name
    }

    # ================================================================
    # 规则 0：Keycloak / 静态资源 / 管理控制台 — 无条件放行
    # ================================================================
    allow := {"allowed": true} if {
        startswith(http_request.path, "/realms/")
    }
    allow := {"allowed": true} if {
        startswith(http_request.path, "/resources/")
    }
    allow := {"allowed": true} if {
        startswith(http_request.path, "/admin/")
    }
    allow := {"allowed": true} if {
        http_request.path == "/health"
        http_request.method == "GET"
    }

    # ================================================================
    # JWT 解码与验签
    # ================================================================
    _bearer_token := token if {
        auth_header := http_request.headers.authorization
        startswith(auth_header, "Bearer ")
        token := substring(auth_header, 7, -1)
    }

    _token_unverified := io.jwt.decode(_bearer_token)
    _token_header := _token_unverified[0]
    _token_payload_unverified := _token_unverified[1]

    _oidc_metadata(issuer) := http.send({
        "url": concat("", [issuer, "/.well-known/openid-configuration"]),
        "method": "GET",
        "force_cache": true,
        "force_cache_duration_seconds": 86400,
    }).body

    _jwks_url := _oidc_metadata(_discovery_issuer).jwks_uri

    _jwks_request(url) := http.send({
        "url": url,
        "method": "GET",
        "force_cache": true,
        "force_cache_duration_seconds": 3600,
    })

    _jwks := jwks_obj if {
        cached := _jwks_request(_jwks_url).body
        cached.keys[_].kid == _token_header.kid
        jwks_obj := cached
    } else := jwks_obj if {
        rotated_url := concat("?", [
            _jwks_url,
            urlquery.encode_object({"kid": _token_header.kid}),
        ])
        jwks_obj := _jwks_request(rotated_url).body
    }

    _token_signature_valid if {
        io.jwt.verify_rs256(_bearer_token, json.marshal(_jwks))
    }

    _token_not_expired if {
        now := time.now_ns() / 1000000000
        _token_payload_unverified.exp > now
    }

    _token_nbf_valid if {
        now := time.now_ns() / 1000000000
        _token_payload_unverified.nbf <= now
    } else := true if {
        not _token_payload_unverified.nbf
    }

    _jwt_verified if {
        _token_signature_valid
        _token_not_expired
        _token_nbf_valid
    }

    _jwt_payload := _token_payload_unverified if {
        _jwt_verified
    }

    # ================================================================
    # 构建 X-Auth-* Headers
    # ================================================================
    _auth_headers[key] := value if {
        payload := _jwt_payload
        some i, entry in [
            ["X-Auth-User-Id", payload.sub],
            ["X-Auth-Username", payload.preferred_username],
            ["X-Auth-Roles", concat(",", payload.realm_access.roles)],
            ["X-Auth-Issuer", payload.iss],
            ["X-Auth-Tenant", _realm_name],
        ]
        key := entry[0]
        value := entry[1]
    }

    _auth_headers["X-Auth-Email"] := _jwt_payload.email if {
        _jwt_payload.email
    }

    # ================================================================
    # RBAC 授权
    # ================================================================

    # 规则 2：super-admin（不受租户隔离限制）
    # /super-admin/{resource}
    # /super-admin/{app}/{resource}
    allow := {"allowed": true, "headers": _auth_headers} if {
        payload := _jwt_payload
        startswith(http_request.path, "/super-admin")
        some role in payload.realm_access.roles
        role == "super_admin"
    }

    # 规则 3：tenant-admin（租户隔离 + 角色校验）
    # /{tenant-id}/{app}/admin/{resource}
    allow := {"allowed": true, "headers": _auth_headers} if {
        payload := _jwt_payload
        _is_tenant_admin_path(http_request.path)
        _tenant_matches
        some role in payload.realm_access.roles
        _admin_roles[role]
    }

    # 规则 4：normal-user（租户隔离 + 角色校验）
    # /{tenant-id}/{app}/{resource}
    allow := {"allowed": true, "headers": _auth_headers} if {
        payload := _jwt_payload
        _is_tenant_normal_path(http_request.path)
        _tenant_matches
        some role in payload.realm_access.roles
        _normal_roles[role]
    }

    # ================================================================
    # 路径判断辅助函数（通用 app 名称）
    #
    # tenant-admin: /{tenant-id}/{app}/admin/{resource}
    #   parts[0]="" parts[1]=tenant parts[2]=app parts[3]="admin" parts[4]=resource
    #
    # normal-user:  /{tenant-id}/{app}/{resource}
    #   parts[0]="" parts[1]=tenant parts[2]=app parts[3]=resource (≠admin)
    # ================================================================

    _is_tenant_admin_path(path) if {
        parts := split(path, "/")
        count(parts) >= 5
        parts[0] == ""
        parts[1] != ""
        parts[2] != ""
        parts[3] == "admin"
    }

    _is_tenant_normal_path(path) if {
        parts := split(path, "/")
        count(parts) >= 4
        parts[0] == ""
        parts[1] != ""
        parts[2] != ""
        parts[3] != "admin"
        parts[3] != "super-admin"
    }

    _admin_roles := {"tenant_admin", "super_admin"}
    _normal_roles := {"default-roles-data-agent", "tenant_admin", "super_admin"}
EOF
```

> **OPA 策略说明**：
> - **结构化返回**：`allow` 返回 `{"allowed": true/false, "headers": {...}}`，而非简单布尔值
> - **Header 注入**：授权通过时，`_auth_headers` 将 JWT payload 中的用户信息（sub、username、roles、email、issuer、tenant_id）注入为 `X-Auth-*` 请求 Header
> - **后端收益**：后端服务无需引入 JWT 库，无需获取公钥验签，直接从 `X-Auth-User-Id`、`X-Auth-Roles` 等 Header 读取已验证的用户信息
> - **`_trusted_issuers`**：使用前端地址（`http://localhost/realms/data-agent`），与 JWT 中的 `iss` 匹配
> - **`_issuer_to_discovery`**：将前端 issuer 映射为集群内地址，OPA 用集群内地址请求 OIDC Discovery
> - **`_jwks_url`**：由于 `backchannel-dynamic=true`，Keycloak 从集群内访问时返回的 `jwks_uri` 自动为集群内地址，OPA 直接使用
> - **扩展方式**：新增 realm 只需在 `_trusted_issuers` 和 `_issuer_to_discovery` 各添加一行
> - **权限继承**：super_admin 可以访问所有三级路径；tenant_admin 可以访问 admin 和 normal 路径；普通用户只能访问 normal 路径

如果 OPA 已在运行，重启使新策略生效：

```bash
kubectl rollout restart deployment opa -n agentgateway-system
kubectl rollout status deployment opa -n agentgateway-system
```

---

## 第 8 步：部署 OPA + Service + ExtAuth 策略

> **注意**：决策路径为 `envoy/authz/allow`，对应策略中的 `allow` 变量，该变量返回结构化对象 `{"allowed": ..., "headers": ...}`。

```bash
kubectl apply -f- <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: opa
  namespace: agentgateway-system
  labels:
    app: opa
spec:
  replicas: 1
  selector:
    matchLabels:
      app: opa
  template:
    metadata:
      labels:
        app: opa
    spec:
      containers:
      - name: opa
        image: openpolicyagent/opa:0.70.0-envoy
        args:
        - "run"
        - "--server"
        - "--addr=0.0.0.0:8181"
        - "--set=plugins.envoy_ext_authz_grpc.addr=:9191"
        - "--set=plugins.envoy_ext_authz_grpc.path=envoy/authz/allow"
        - "--set=decision_logs.console=true"
        - "--ignore=.*"
        - "/policy/policy.rego"
        ports:
        - containerPort: 9191
          name: grpc
        - containerPort: 8181
          name: http
        volumeMounts:
        - name: opa-policy
          mountPath: /policy
          readOnly: true
        livenessProbe:
          httpGet:
            path: /health
            port: 8181
          initialDelaySeconds: 5
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health?plugins
            port: 8181
          initialDelaySeconds: 5
          periodSeconds: 10
      volumes:
      - name: opa-policy
        configMap:
          name: opa-policy
---
apiVersion: v1
kind: Service
metadata:
  name: opa
  namespace: agentgateway-system
  labels:
    app: opa
spec:
  ports:
  - port: 9191
    targetPort: 9191
    protocol: TCP
    name: grpc
  selector:
    app: opa
---
# =============================================
# ext_authz 策略 — 挂到 super-admin-route
# keycloak-route、keycloak-static-route 和 keycloak-admin-route 没有挂策略
# =============================================
apiVersion: agentgateway.dev/v1alpha1
kind: AgentgatewayPolicy
metadata:
  name: super-admin-auth-policy
  namespace: agentgateway-system
spec:
  targetRefs:
  - group: gateway.networking.k8s.io
    kind: HTTPRoute
    name: super-admin-route
  traffic:
    extAuth:
      backendRef:
        name: opa
        namespace: agentgateway-system
        port: 9191
      grpc: {}
---
# =============================================
# ext_authz 策略 — 挂到 tenant-api-route
# =============================================
apiVersion: agentgateway.dev/v1alpha1
kind: AgentgatewayPolicy
metadata:
  name: tenant-api-auth-policy
  namespace: agentgateway-system
spec:
  targetRefs:
  - group: gateway.networking.k8s.io
    kind: HTTPRoute
    name: tenant-api-route
  traffic:
    extAuth:
      backendRef:
        name: opa
        namespace: agentgateway-system
        port: 9191
      grpc: {}
EOF
```

验证 OPA 正常运行：

```bash
kubectl get pods -n agentgateway-system -l app=opa
# 应显示 1/1 Running
```

---

## 第 9 步：验证完整流程

### 9.1 获取新 Token（走 Gateway）

```bash
ACCESS_TOKEN=$(curl -s -X POST \
  "http://localhost/realms/data-agent/protocol/openid-connect/token" \
  -d "grant_type=password" \
  -d "client_id=opa-test" \
  -d "client_secret=NNDfLU9ox3PdiVd9U95I8KuaYQP4YN2S" \
  -d "username=g-e3c69453-4887-423b-9d17-709cff4d862a" \
  -d "password=Test@123456" | jq -r '.access_token')

echo "Token: ${ACCESS_TOKEN:0:50}..."
```

### 9.2 执行测试

**测试 1：Keycloak 端点无 auth → 200 ✅**

```bash
curl -i http://localhost/realms/data-agent/.well-known/openid-configuration
# 预期: HTTP/1.1 200 OK
```

**测试 2：无 Token → 403 Forbidden**

```bash
curl -i http://localhost/huaxi/data-agent/records
# 预期: HTTP/1.1 403 Forbidden（OPA default deny）
```

**测试 3：伪造 Token → 403 Forbidden**

```bash
curl -i http://localhost/huaxi/data-agent/records \
  -H "Authorization: Bearer eyJhbGciOiJSUzI1NiJ9.FAKE.TOKEN"
# 预期: HTTP/1.1 403 Forbidden（OPA 验签失败）
```

**测试 4：普通联邦用户 → normal-user 路径 → 200 ✅ + X-Auth-* Headers**

```bash
curl -s http://localhost/huaxi/data-agent/records \
  -H "Authorization: Bearer $ACCESS_TOKEN" | jq '.headers'
# 预期: HTTP/1.1 200 OK
# 返回的 headers 中应包含 OPA 注入的 X-Auth-* Headers：
# "X-Auth-User-Id": "f47ac10b-58cc-...",
# "X-Auth-Username": "g-5e3f01eb-...",
# "X-Auth-Roles": "default-roles-data-agent,offline_access,...",
# "X-Auth-Issuer": "http://localhost/realms/data-agent",
# "X-Auth-Email": "..." (如有),
# "X-Auth-Tenant-Id": "huaxi" (如已配置 tenant_id claim)
```

**测试 5：普通联邦用户 → tenant-admin 路径 → 403 ❌**

```bash
curl -i http://localhost/huaxi/data-agent/admin/settings \
  -H "Authorization: Bearer $ACCESS_TOKEN"
# 预期: HTTP/1.1 403 Forbidden
```

**测试 6：普通联邦用户 → super-admin 路径 → 403 ❌**

```bash
curl -i http://localhost/data-agent/super-admin/users \
  -H "Authorization: Bearer $ACCESS_TOKEN"
# 预期: HTTP/1.1 403 Forbidden
```

**测试 7：tenant_admin 用户 → admin 路径 → 200 ✅ + X-Auth-* Headers**

```bash
curl -s http://localhost/huaxi/data-agent/admin/settings \
  -H "Authorization: Bearer $ACCESS_TOKEN" | jq '.headers | with_entries(select(.key | startswith("X-Auth")))'
# 预期: HTTP/1.1 200 OK（需已分配 tenant_admin 角色）
# 返回 X-Auth-* Headers
```

**测试 8：super_admin 用户 → super-admin 路径 → 200 ✅ + X-Auth-* Headers**

```bash
curl -s http://localhost/data-agent/super-admin/users \
  -H "Authorization: Bearer $ACCESS_TOKEN" | jq '.headers | with_entries(select(.key | startswith("X-Auth")))'
# 预期: HTTP/1.1 200 OK（需已分配 super_admin 角色）
# 返回 X-Auth-* Headers
```

### 9.3 验证 Header 注入详情

```bash
# 获取完整的 X-Auth-* Headers（httpbin 会将收到的所有 headers 返回在 JSON 中）
curl -s http://localhost/huaxi/data-agent/records \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  | jq '{
    "X-Auth-User-Id": .headers["X-Auth-User-Id"],
    "X-Auth-Username": .headers["X-Auth-Username"],
    "X-Auth-Roles": .headers["X-Auth-Roles"],
    "X-Auth-Email": .headers["X-Auth-Email"],
    "X-Auth-Issuer": .headers["X-Auth-Issuer"],
    "X-Auth-Tenant-Id": .headers["X-Auth-Tenant-Id"]
  }'
# 预期输出：
# {
#   "X-Auth-User-Id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
#   "X-Auth-Username": "g-5e3f01eb-...",
#   "X-Auth-Roles": "tenant_admin,default-roles-data-agent,offline_access,uma_authorization",
#   "X-Auth-Email": "user@example.com",
#   "X-Auth-Issuer": "http://localhost/realms/data-agent",
#   "X-Auth-Tenant-Id": null
# }
```

### 9.4 浏览器登录测试

```bash
# 1. 把 HTML 文件创建为 ConfigMap
kubectl create configmap auth-dashboard \
  --from-file=auth-dashboard.html=auth-dashboard.html \
  -n agentgateway-system

# 2. 部署 nginx 来 serve 这个文件
kubectl apply -f- <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: dashboard
  namespace: agentgateway-system
spec:
  replicas: 1
  selector:
    matchLabels:
      app: dashboard
  template:
    metadata:
      labels:
        app: dashboard
    spec:
      containers:
      - name: nginx
        image: nginx:alpine
        ports:
        - containerPort: 80
        volumeMounts:
        - name: html
          mountPath: /usr/share/nginx/html
          readOnly: true
      volumes:
      - name: html
        configMap:
          name: auth-dashboard
---
apiVersion: v1
kind: Service
metadata:
  name: dashboard
  namespace: agentgateway-system
spec:
  selector:
    app: dashboard
  ports:
  - port: 80
    targetPort: 80
---
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: dashboard-route
  namespace: agentgateway-system
spec:
  parentRefs:
  - name: agentgateway-proxy
    namespace: agentgateway-system
  hostnames:
  - "localhost"
  rules:
  - matches:
    - path:
        type: Exact
        value: /auth-dashboard.html
    backendRefs:
    - name: dashboard
      port: 80
EOF

kubectl get pods -n agentgateway-system -l app=dashboard
```

更新 Dashboard 文件时：

```bash
# 1. 删除旧 ConfigMap，重新创建
kubectl delete configmap auth-dashboard -n agentgateway-system
kubectl create configmap auth-dashboard \
  --from-file=auth-dashboard.html=auth-dashboard.html \
  -n agentgateway-system

# 2. 重启 nginx 让它读到新文件
kubectl rollout restart deployment dashboard -n agentgateway-system
```

在浏览器中打开 `http://localhost/auth-dashboard.html`，点击"Keycloak 登录"：

1. 浏览器跳转到 `http://localhost/realms/data-agent/protocol/openid-connect/auth?...`
2. Gateway 的 keycloak-route 匹配 `/realms/*`，转发到 Keycloak
3. Keycloak 显示登录页面（通过 `kc_idp_hint=saml` 自动跳转到 Huaxi Hospital IdP）
4. 登录成功后 Keycloak redirect 回 Dashboard，携带 authorization code
5. Dashboard 用 code 换取 access_token（token endpoint 也走 Gateway）
6. 完成！Token 中的 `iss` 为 `http://localhost/realms/data-agent`
7. 运行测试后，测试卡片会显示后端收到的 `X-Auth-*` Headers

### 9.5 验证 backchannel-dynamic 效果

```bash
# 从集群内访问 OIDC Discovery，验证 backchannel 端点为集群内地址
kubectl run curl-test --rm -it --image=curlimages/curl --image-pull-policy=IfNotPresent --restart=Never -- \
  curl -s "http://keycloak.keycloak.svc.cluster.local:8080/realms/data-agent/.well-known/openid-configuration" 2>/dev/null | jq '{issuer, jwks_uri, token_endpoint}'
# 预期:
# {
#   "issuer": "http://localhost/realms/data-agent",          ← 固定前端地址
#   "jwks_uri": "http://keycloak.keycloak.svc.cluster.local:8080/...",   ← 集群内地址！
#   "token_endpoint": "http://keycloak.keycloak.svc.cluster.local:8080/..." ← 集群内地址！
# }
```

### 9.6 测试结果汇总

| 场景 | 路径 | 角色 | 预期 | 拦截层 | X-Auth-* Headers | 原因 |
| --- | --- | --- | --- | --- | --- | --- |
| Keycloak 端点 | /realms/data-agent/... | — | **200** ✅ | — | 无 | keycloak-route 无 auth |
| Keycloak 静态资源 | /resources/... | — | **200** ✅ | — | 无 | keycloak-static-route 无 auth |
| Keycloak 管理控制台 | /admin/master/console/ | — | **200** ✅ | — | 无 | keycloak-admin-route 无 auth |
| 无 Token | 任意业务路径 | — | **403** | OPA | 无 | 无 token，default deny |
| 伪造 Token | 任意业务路径 | — | **403** | OPA | 无 | 签名验证失败 |
| 过期 Token | 任意业务路径 | — | **403** | OPA | 无 | exp 过期 |
| 普通用户 | /huaxi/data-agent/records | default-roles | **200** ✅ | — | ✅ 注入 | 有 normal-user 权限 |
| 普通用户 | /huaxi/data-agent/admin/settings | default-roles | **403** | OPA | 无 | 无 tenant_admin 角色 |
| 普通用户 | /data-agent/super-admin/users | default-roles | **403** | OPA | 无 | 无 super_admin 角色 |
| tenant_admin | /huaxi/data-agent/admin/settings | tenant_admin | **200** ✅ | — | ✅ 注入 | 有 admin 权限 |
| tenant_admin | /huaxi/data-agent/records | tenant_admin | **200** ✅ | — | ✅ 注入 | admin 含 normal 权限 |
| tenant_admin | /data-agent/super-admin/users | tenant_admin | **403** | OPA | 无 | 无 super_admin 角色 |
| super_admin | /data-agent/super-admin/users | super_admin | **200** ✅ | — | ✅ 注入 | 有超管权限 |
| super_admin | /huaxi/data-agent/admin/settings | super_admin | **200** ✅ | — | ✅ 注入 | 超管含所有权限 |
| 浏览器登录 | Authorization Code Flow | — | **成功** ✅ | — | — | 全部走 Gateway 代理 |

---

## 调试指南

### 查看 OPA 决策日志

```bash
kubectl logs -n agentgateway-system -l app=opa -f
```

### 检查 Policy 状态

```bash
kubectl get AgentgatewayPolicy -n agentgateway-system
kubectl get AgentgatewayPolicy super-admin-auth-policy -n agentgateway-system -o json | jq '.status'
kubectl get AgentgatewayPolicy tenant-api-auth-policy -n agentgateway-system -o json | jq '.status'
```

### 验证 backchannel-dynamic 是否生效

```bash
# 从集群内访问：jwks_uri 和 token_endpoint 应为集群内地址
kubectl run curl-test --rm -it --image=curlimages/curl --image-pull-policy=IfNotPresent --restart=Never -- \
  curl -s "http://keycloak.keycloak.svc.cluster.local:8080/realms/data-agent/.well-known/openid-configuration" 2>/dev/null | jq '.jwks_uri'

# 从外部访问：jwks_uri 和 token_endpoint 应为外部地址
curl -s http://localhost/realms/data-agent/.well-known/openid-configuration | jq '.jwks_uri'
```

### 验证 Header 注入是否生效

```bash
# 通过 httpbin 查看后端收到的所有 headers
curl -s http://localhost/huaxi/data-agent/records \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  | jq '.headers | with_entries(select(.key | startswith("X-Auth")))'

# 如果输出为空或无 X-Auth-* headers，检查：
# 1. OPA 日志中的决策结果是否包含 headers 字段
# 2. OPA 决策路径是否为 envoy/authz/allow
# 3. OPA 策略中 allow 的返回值是否为结构化对象
```

### 常见问题

**Q: 带 token 仍返回 403**
- 确认 token 的 `iss` 为 `http://localhost/realms/data-agent`（前端地址）
- 确认 OPA 白名单 `_trusted_issuers` 包含此 issuer
- 确认 OPA `_issuer_to_discovery` 映射表中包含对应条目
- 检查 OPA 日志确认 OIDC Discovery 和 JWKS 获取是否成功
- 确认 token 未过期（默认有效期 5 分钟）

**Q: 200 OK 但后端没有收到 X-Auth-* Headers**
- 检查 OPA 日志，确认决策结果中包含 `headers` 字段
- 确认 OPA Deployment 的决策路径为 `envoy/authz/allow`
- 确认 OPA 策略中 `allow` 返回的是 `{"allowed": true, "headers": _auth_headers}` 而非简单的 `true`
- 确认 agentgateway ext_authz 支持从 OPA 结构化返回中提取 headers 并注入到上游请求

**Q: OPA 的 http.send 无法访问 OIDC Discovery**
- OPA 使用 `_issuer_to_discovery` 中的集群内地址访问 Keycloak
- 检查 Keycloak Service 是否正常：`kubectl get svc -n keycloak keycloak`
- 检查 `KC_HOSTNAME_BACKCHANNEL_DYNAMIC=true` 是否生效（用上面的验证命令确认 jwks_uri 返回集群内地址）

**Q: 浏览器访问 Keycloak 登录页面白屏或资源加载失败**
- 确认 `keycloak-static-route`（`/resources/*`）已部署
- 检查浏览器开发者工具 Network 面板，确认 `/resources/...` 请求返回 200

**Q: 浏览器登录后 redirect 失败**
- 确认浏览器地址栏使用 `http://localhost`
- 确认 port-forward 和 SSH 隧道正常运行（端口 80）
- 确认 Keycloak `da-client` 的 Valid Redirect URIs 包含 `http://localhost/*`
- 确认 `da-client` 的 Web Origins 包含 `http://localhost` 或 `*`

**Q: 浏览器无法访问 Keycloak 管理控制台**
- 确认 `keycloak-admin-route`（`/admin/*`）已部署：`kubectl get httproute keycloak-admin-route -n agentgateway-system`
- 浏览器访问 `http://localhost/admin/master/console/`
- 如果页面跳转异常，检查 `KC_HOSTNAME` 是否为 `http://localhost`（管理控制台的内部链接使用此地址）
- 备选方案：`kubectl port-forward -n keycloak svc/keycloak 9080:8080`，然后访问 `http://localhost:9080/admin/master/console/`

**Q: 如何限制用户只能访问自己租户的数据？**
- 在 Keycloak 中通过 Protocol Mapper 向 token 添加 `tenant_id` claim
- OPA 策略已自动将 `tenant_id` 注入为 `X-Auth-Tenant-Id` Header（如 token 中存在）
- 在 OPA 中校验 JWT payload 的 `tenant_id` 与 URL 中的 `{tenant-id}` 是否匹配（见附录 A）

---

## 前端集成参考

v11 架构下前端应用直接使用浏览器 Authorization Code Flow，所有 Keycloak 端点走 Gateway：

```javascript
const config = {
  authority: "http://localhost/realms/data-agent",
  clientId: "da-client",
  redirectUri: "http://localhost/callback",
  scope: "openid profile email",
};

function login() {
  const url = `${config.authority}/protocol/openid-connect/auth?` +
    `client_id=${config.clientId}&` +
    `response_type=code&` +
    `scope=${config.scope}&` +
    `redirect_uri=${encodeURIComponent(config.redirectUri)}&` +
    `kc_idp_hint=saml`;
  window.location.href = url;
}

async function handleCallback(code) {
  const res = await fetch(
    `${config.authority}/protocol/openid-connect/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: config.clientId,
        code: code,
        redirect_uri: config.redirectUri,
      }),
    }
  );
  const data = await res.json();
  return data.access_token;
}

async function callApi(token, tenantId) {
  // 后端会收到 OPA 注入的 X-Auth-* Headers，无需自行解析 JWT
  const records = await fetch(`/${tenantId}/data-agent/records`, {
    headers: { "Authorization": `Bearer ${token}` },
  });
  const settings = await fetch(`/${tenantId}/data-agent/admin/settings`, {
    headers: { "Authorization": `Bearer ${token}` },
  });
  const users = await fetch(`/data-agent/super-admin/users`, {
    headers: { "Authorization": `Bearer ${token}` },
  });
}
```

### 后端集成参考（读取 X-Auth-* Headers）

后端无需引入 JWT 库，直接从请求 Header 读取已验证的用户信息：

```python
# Python / Flask 示例
from flask import request

@app.route('/<tenant_id>/data-agent/records')
def get_records(tenant_id):
    user_id = request.headers.get('X-Auth-User-Id')
    username = request.headers.get('X-Auth-Username')
    roles = request.headers.get('X-Auth-Roles', '').split(',')
    email = request.headers.get('X-Auth-Email')
    issuer = request.headers.get('X-Auth-Issuer')
    auth_tenant = request.headers.get('X-Auth-Tenant-Id')

    # 直接使用，无需 JWT 验签
    return {'user': username, 'roles': roles, 'tenant': tenant_id}
```

```go
// Go / net/http 示例
func handleRecords(w http.ResponseWriter, r *http.Request) {
    userID := r.Header.Get("X-Auth-User-Id")
    username := r.Header.Get("X-Auth-Username")
    roles := strings.Split(r.Header.Get("X-Auth-Roles"), ",")
    email := r.Header.Get("X-Auth-Email")

    // 直接使用，无需 JWT 验签
    fmt.Fprintf(w, "User: %s, Roles: %v", username, roles)
}
```

---

## 附录 A：租户隔离扩展（可选）

### 1. 在 Keycloak 中添加 tenant_id claim

在 `data-agent` realm 中为 `da-client` client 添加 Protocol Mapper：
- Mapper Type: `User Attribute`
- User Attribute: `tenant_id`
- Token Claim Name: `tenant_id`
- Add to access token: ON

### 2. 扩展 OPA 策略

```rego
_user_tenant_matches(path) if {
    payload := _jwt_payload
    parts := split(path, "/")
    tenant_from_url := parts[1]
    payload.tenant_id == tenant_from_url
}
```

> v11 中 OPA 已自动将 `tenant_id` 注入为 `X-Auth-Tenant-Id` Header（如 token 中存在该字段），后端可直接从 Header 读取并做额外校验。

---

## 附录 B：生产环境迁移指南

| 维度 | 开发/测试（v11 当前） | 生产环境 |
| --- | --- | --- |
| Gateway 暴露方式 | port-forward 80（需 sudo） | LoadBalancer / Ingress（标准 80/443） |
| KC_HOSTNAME | `http://localhost` | `https://gateway.your-domain.com` |
| DNS | 无需配置（localhost） | 真实 DNS A 记录 |
| TLS | 无 | 必须启用 |
| OPA 白名单 | 更新外部地址 | 同步更新 |
| backchannel-dynamic | 保持 `true` | 保持 `true`（集群内地址不变） |
| X-Auth-* Headers | 后端信任 Header | 确保 Gateway 是唯一入口，防止 Header 伪造 |

> **安全提醒**：在生产环境中，必须确保 `X-Auth-*` Headers 只能由 OPA 注入，不能被外部请求伪造。Gateway 应作为唯一入口，后端服务不对外暴露。

---

## 附录 C：从 v10 升级到 v11

如果已经部署了 v10 版本，只需以下两步即可升级到 v11：

### 步骤 1：更新 OPA 策略 ConfigMap

执行第 7 步中的 `kubectl apply` 命令，替换 `opa-policy` ConfigMap。

### 步骤 2：重启 OPA

```bash
kubectl rollout restart deployment opa -n agentgateway-system
kubectl rollout status deployment opa -n agentgateway-system
```

> **注意**：OPA Deployment 的决策路径 `envoy/authz/allow` 无需修改（v11 策略中变量名仍为 `allow`，但返回值从布尔值变为结构化对象）。

### 验证升级

```bash
ACCESS_TOKEN=$(curl -s -X POST \
  "http://localhost/realms/data-agent/protocol/openid-connect/token" \
  -d "grant_type=password" \
  -d "client_id=da-client" \
  -d "username=geteway_user" \
  -d "password=huawei@123" | jq -r '.access_token')

echo $ACCESS_TOKEN

# 确认 X-Auth-* Headers 已注入
curl -s http://localhost/huaxi/data-agent/records \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  | jq '.headers | with_entries(select(.key | startswith("X-Auth")))'

# 解码查看 token 内容
echo $ACCESS_TOKEN | cut -d'.' -f2 | base64 --decode 2>/dev/null | jq .
```

---

## 清理资源

```bash
# 删除策略
kubectl delete AgentgatewayPolicy super-admin-auth-policy -n agentgateway-system 2>/dev/null
kubectl delete AgentgatewayPolicy tenant-api-auth-policy -n agentgateway-system 2>/dev/null

# 删除 OPA
kubectl delete deployment opa -n agentgateway-system
kubectl delete service opa -n agentgateway-system
kubectl delete configmap opa-policy -n agentgateway-system

# 删除 Dashboard
kubectl delete deployment dashboard -n agentgateway-system 2>/dev/null
kubectl delete service dashboard -n agentgateway-system 2>/dev/null
kubectl delete httproute dashboard-route -n agentgateway-system 2>/dev/null
kubectl delete configmap auth-dashboard -n agentgateway-system 2>/dev/null

# 删除路由
kubectl delete httproute keycloak-route -n agentgateway-system
kubectl delete httproute keycloak-static-route -n agentgateway-system
kubectl delete httproute keycloak-admin-route -n agentgateway-system
kubectl delete httproute super-admin-route -n agentgateway-system
kubectl delete httproute tenant-api-route -n agentgateway-system
kubectl delete referencegrant allow-routes-to-httpbin -n httpbin
kubectl delete referencegrant allow-routes-to-keycloak -n keycloak

# 关闭 port-forward
pkill -f "kubectl port-forward"
```
