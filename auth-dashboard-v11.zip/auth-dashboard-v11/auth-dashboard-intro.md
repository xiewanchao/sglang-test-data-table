# 🛡 AgentGateway Auth Dashboard 介绍

**三级 RBAC 认证授权演示界面**

`v11-localhost` · `backchannel-dynamic` · `Header 注入`

> Keycloak + OPA + AgentGateway 集成演示
> OPA 统一完成 JWT 验签、RBAC 授权与 X-Auth-* Header 注入

---

## 1 项目背景

在微服务和 API 网关架构中，身份认证与权限控制是核心安全需求。本项目基于 Kubernetes 环境，将 Keycloak（身份认证）、OPA（策略引擎）和 AgentGateway（流量代理）三者整合，实现了一套完整的三级 RBAC 权限控制方案。

Auth Dashboard 是该方案的配套演示界面，用于直观展示认证授权流程的每个环节，方便开发者和运维人员理解、调试和验证整个系统的运行状态。

---

## 2 系统架构概览

整体请求链路：

```
浏览器 → SSH 隧道 → AgentGateway → OPA 验签授权 → 后端服务（httpbin）
                          ↕
                       Keycloak（身份提供方）
```

核心设计理念是「OPA 统一负责验签 + 授权 + Header 注入」。Gateway 本身不做 JWT 验证，而是通过 ext_authz 机制将所有认证决策委托给 OPA。OPA 验签通过后，将用户身份信息以 `X-Auth-*` Headers 的形式注入到请求中转发给后端，使后端无需自行解析 JWT。

### 2.1 三级权限模型

系统定义了三个权限级别，权限向下兼容：

| 级别 | URL 模式 | 所需角色 | 说明 |
|------|----------|----------|------|
| **超级管理员** | `/super-admin/{app}/{resource}` | `super_admin` | 跨租户全局管理 |
| **租户管理员** | `/{tenant-id}/{app}/admin/{resource}` | `tenant_admin` | 管理本租户 |
| **普通用户** | `/{tenant-id}/{app}/{resource}` | `default-roles-data-agent` | 访问租户数据 |

- `super_admin` 可访问所有三级路径
- `tenant_admin` 可访问 admin + normal 路径
- 普通用户仅可访问 normal 路径

### 2.2 Gateway 路由分流

AgentGateway 通过 HTTPRoute 将请求分为五类，其中仅业务路由挂载 OPA ext_authz 策略：

- `/realms/*` → Keycloak OIDC 端点（无 auth，裸透传）
- `/resources/*` → Keycloak 静态资源（无 auth）
- `/admin/*` → Keycloak 管理控制台（无 auth）
- `/super-admin/*` → 超管路由（需 OPA auth）
- `/*` → 租户 API 兜底路由（需 OPA auth）

### 2.3 OPA 注入的 X-Auth-* Headers

OPA 授权通过后，会将以下 Headers 注入到请求中，后端可直接读取：

| Header | 来源 | 示例值 |
|--------|------|--------|
| `X-Auth-User-Id` | `payload.sub` | `f47ac10b-58cc-...` |
| `X-Auth-Username` | `payload.preferred_username` | `g-5e3f01eb-...` |
| `X-Auth-Roles` | `payload.realm_access.roles` | `tenant_admin,default-roles-data-agent` |
| `X-Auth-Email` | `payload.email` | `user@example.com` |
| `X-Auth-Issuer` | `payload.iss` | `http://localhost/realms/data-agent` |
| `X-Auth-Tenant-Id` | `payload.tenant_id` | `huaxi` |

---

## 3 Dashboard 功能介绍

### 3.1 认证区域（顶部）

页面顶部包含以下交互元素：

- **租户 ID 输入框** — 可切换当前测试的租户标识（如 `data-agent`、`huaxi` 等）
- **清除会话按钮** — 强制清除 Keycloak session，解决切换用户时的会话冲突
- **Keycloak 登录按钮** — 触发 Authorization Code Flow + PKCE 登录流程

登录成功后，面板会显示当前用户的 issuer、username、client、email 以及 realm 角色信息。同时显示 token 的 TTL 倒计时，方便判断 token 是否即将过期。

### 3.2 API 路由模型卡片

登录区域下方展示了两类路由模型的简明对照表，帮助用户快速理解 tenant-admin 与 normal-user 路径的结构差异和角色要求。

### 3.3 测试用例网格（核心功能）

Dashboard 的核心是测试用例网格，包含四个测试分组：

1. **认证测试（与角色无关）** — 验证无 Token 请求返回 403、伪造 Token 返回 403
2. **Keycloak 端点测试** — 验证 OIDC Discovery 和 JWKS 公钥端点可通过 Gateway 正常访问
3. **normal-user / tenant-admin / super-admin 路径测试** — 根据当前登录用户的角色动态计算预期结果
4. **Header 注入验证** — 授权通过的测试卡片会展示后端收到的 X-Auth-* Headers

每张测试卡片展示的信息包括：测试名称、权限层级标签（SUPER-ADMIN / TENANT-ADMIN / NORMAL-USER / 认证）、请求方法与路径、预期结果、实际返回状态码、响应时间，以及 PASS/FAIL 判定。

**智能预期计算**：测试用例会根据当前登录用户的角色级别自动调整预期结果。例如，当以 `tenant_admin` 身份登录时，admin 路径预期 200、super-admin 路径预期 403；切换为 `super_admin` 后，所有路径均预期 200。

### 3.4 控制台日志

页面底部的 Console 区域实时输出每次测试的详细过程：请求发起、Token 携带情况、响应状态码、耗时，以及后端收到的注入 Headers。日志使用颜色编码（绿色=通过、红色=失败、蓝色=信息），方便快速定位问题。

---

## 4 关键技术实现

### 4.1 PKCE 认证流程

Dashboard 使用 Public Client（`da-client`），通过 Authorization Code Flow + PKCE 完成登录，前端无需存储任何 client secret。流程概要：

1. 生成 PKCE `code_verifier` 和 `code_challenge`，存入 sessionStorage
2. 跳转 Keycloak 授权端点，携带 `kc_idp_hint=saml` 自动触发联邦登录
3. 回调后用 authorization code + code_verifier 换取 access_token
4. 解码 JWT 提取角色信息，动态更新测试用例预期

### 4.2 backchannel-dynamic 机制

v11 版本的核心创新在于 `KC_HOSTNAME_BACKCHANNEL_DYNAMIC=true` 配置：

- **前端（浏览器）**：issuer、jwks_uri 等均为 `http://localhost/realms/data-agent`
- **后端（OPA 集群内）**：jwks_uri 自动返回集群内地址，OPA 可直接访问
- **无需任何 issuer 映射表**，无需 hosts 文件配置，开箱即用

### 4.3 同域无 CORS 架构

Dashboard、Keycloak、业务 API 全部通过 Gateway 统一代理，共享 `localhost` 域名和端口 80。由于同源策略满足，前端 fetch 请求无需处理 CORS 问题，极大简化了开发和调试体验。

---

## 5 环境搭建

要在本地运行 Dashboard，需完成以下准备：

**① K8s 服务器端** — 执行 port-forward 将 Gateway 80 端口暴露：

```bash
sudo kubectl port-forward svc/agentgateway-proxy -n agentgateway-system 80:80 --address 0.0.0.0
```

**② 本机 SSH 隧道** — 将远程 80 端口映射到本地：

```bash
sudo ssh -L 80:127.0.0.1:80 <k8s-server>
```

**③ 浏览器访问**：

```
http://localhost/auth-dashboard.html
```

> 端口 80 在 Linux/Mac 上是特权端口，port-forward 和 SSH 隧道需 `sudo`。如不想用 sudo，可改为高端口（如 8080），相应修改 `KC_HOSTNAME` 和所有 URL。

---

## 6 使用演示流程

1. **未登录状态运行测试** — 点击「运行所有测试」，观察认证测试和 Keycloak 端点测试的结果。无 Token 和伪造 Token 均返回 403，OIDC Discovery 和 JWKS 端点返回 200。

2. **登录并观察角色** — 点击「Keycloak 登录」，完成联邦认证后返回 Dashboard。查看 Token 面板中的角色标签，确认当前用户的权限级别。

3. **再次运行测试** — 观察各路径的测试结果随角色变化。普通用户仅 normal 路径通过；tenant_admin 同时通过 admin 和 normal；super_admin 全部通过。

4. **查看 Header 注入** — 在通过的测试卡片下方展开「Gateway 注入的 Headers」区域，确认后端收到了 X-Auth-User-Id、X-Auth-Roles 等信息。

5. **切换租户测试隔离** — 修改右上角的 tenant-id 输入框（如改为 `other-tenant`），运行测试，观察租户隔离策略如何阻止跨租户访问。

---

## 7 总结

Auth Dashboard 作为 Keycloak + OPA + AgentGateway 认证授权方案的可视化验证工具，具备以下特点：

- **全流程可视化** — 从 Token 获取到 RBAC 判定，再到 Header 注入，每一步都有对应的 UI 展示
- **角色感知的动态测试** — 测试预期结果随用户角色自动调整，无需手动计算
- **零配置本地运行** — 基于 localhost + backchannel-dynamic，无需 hosts 文件或额外 DNS
- **开发调试友好** — Console 日志提供详细的请求/响应信息，便于排查问题
- **后端集成示范** — 展示 X-Auth-* Headers 注入机制，后端无需 JWT 库即可获取用户信息

---

*本文档基于 v11-localhost 版本，对应 OPA OIDC Discovery + KC_HOSTNAME_BACKCHANNEL_DYNAMIC 架构。*
